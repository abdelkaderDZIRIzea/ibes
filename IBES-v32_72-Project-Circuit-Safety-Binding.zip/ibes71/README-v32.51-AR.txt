IBES v32.51 — Project Source Only

هذه حزمة مصدر المشروع فقط. لا يتم إصدار حزمة HTML مستقلة أو حزمة Desktop مستقلة في هذه المرحلة.

ابدأ بقراءة REPORT-v32.51-AR.txt وCHANGELOG-v32.51-AR.txt.

نموذج الدوائر الكهربائية الجديد:
- engineering/electrical-circuit-model.cjs
- tests/electrical-circuit-model.test.cjs

مهم: هذه المرحلة تضيف عقد البيانات والتحقق والترحيل غير الإتلافي، ولا تدعي أن واجهة الدوائر أو المخطط الأحادي أو التقارير أصبحت متكاملة بعد.
