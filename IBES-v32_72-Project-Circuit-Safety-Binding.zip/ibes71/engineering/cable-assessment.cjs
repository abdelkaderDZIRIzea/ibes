/* IBES cable assessment v1.0.0
 * Uses externally verified reference ampacity and correction factors only.
 * Does not infer ampacity from conductor section or claim NF C 15-100 conformity.
 */
(function(root){'use strict';
 const VERSION='ibes-cable-assessment-1.0.0';
 const number=(v,name,{positive=true,max=null}={})=>{
  if(v===null||v===undefined||v===''||typeof v==='boolean'||!Number.isFinite(Number(v))) throw new TypeError(name+' must be an explicitly supplied finite number');
  const n=Number(v);
  if(positive?n<=0:n<0) throw new RangeError(name+(positive?' must be > 0':' must be ≥ 0'));
  if(max!==null&&n>max) throw new RangeError(name+' must be ≤ '+max);
  return n;
 };
 function assess(input){
  if(!input||typeof input!=='object'||Array.isArray(input)) throw new TypeError('input must be an object');
  const missing=[];
  for(const key of ['designCurrentA','breakerRatingA','referenceAmpacityA','referenceSource','installationMethod','conductorMaterial','insulationType']){
   if(input[key]===undefined||input[key]===null||input[key]==='') missing.push(key);
  }
  if(!Array.isArray(input.correctionFactors)||input.correctionFactors.length===0) missing.push('correctionFactors');
  if(missing.length) return {engineVersion:VERSION,status:'NEEDS_DATA',normativeCompliance:'NOT_ASSESSED',missingInputs:[...new Set(missing)],message:'No cable capacity or protection conclusion is produced until all required inputs and the reference source are supplied.'};
  const Ib=number(input.designCurrentA,'designCurrentA');
  const In=number(input.breakerRatingA,'breakerRatingA');
  const base=number(input.referenceAmpacityA,'referenceAmpacityA');
  if(typeof input.referenceSource!=='string'||!input.referenceSource.trim()) throw new TypeError('referenceSource must identify the verified source/table and edition');
  if(typeof input.installationMethod!=='string'||!input.installationMethod.trim()) throw new TypeError('installationMethod must be explicit');
  if(typeof input.conductorMaterial!=='string'||!input.conductorMaterial.trim()) throw new TypeError('conductorMaterial must be explicit');
  if(typeof input.insulationType!=='string'||!input.insulationType.trim()) throw new TypeError('insulationType must be explicit');
  const factors=input.correctionFactors.map((f,i)=>{
   if(!f||typeof f!=='object'||Array.isArray(f)) throw new TypeError('correctionFactors['+i+'] must include id and value');
   if(typeof f.id!=='string'||!f.id.trim()) throw new TypeError('correctionFactors['+i+'].id is required');
   return {id:f.id.trim(),value:number(f.value,'correctionFactors['+i+'].value',{positive:true,max:1})};
  });
  const seen=new Set();
  for(const f of factors){if(seen.has(f.id)) throw new RangeError('duplicate correction factor: '+f.id);seen.add(f.id);}
  const multiplier=factors.reduce((a,f)=>a*f.value,1);
  const Iz=base*multiplier;
  if(!Number.isFinite(Iz)||Iz<=0) throw new RangeError('corrected ampacity result is outside the supported numeric range');
  const checks=[
   {id:'Ib_le_In',formula:'Ib ≤ In',passed:Ib<=In,actual:Ib,limit:In},
   {id:'In_le_Iz',formula:'In ≤ Iz',passed:In<=Iz,actual:In,limit:Iz}
  ];
  const passed=checks.every(c=>c.passed);
  return {engineVersion:VERSION,status:passed?'PASS_BASIC_CURRENT_COORDINATION':'FAIL_BASIC_CURRENT_COORDINATION',normativeCompliance:'NOT_ASSESSED',inputs:{designCurrentA:Ib,breakerRatingA:In,referenceAmpacityA:base,referenceSource:input.referenceSource.trim(),installationMethod:input.installationMethod.trim(),conductorMaterial:input.conductorMaterial.trim(),insulationType:input.insulationType.trim(),correctionFactors:factors},correctionMultiplier:multiplier,correctedCableCapacityA:Iz,checks,limitations:['Reference ampacity and factors must be verified for the actual installation and applicable standard edition.','Does not verify short-circuit breaking capacity, disconnection time, thermal withstand, voltage drop, grouping completeness, ambient conditions or all NF C 15-100 requirements.']};
 }
 const api=Object.freeze({version:VERSION,assess});
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
 if(root)root.IBESCableAssessment=api;
})(typeof window!=='undefined'?window:globalThis);
