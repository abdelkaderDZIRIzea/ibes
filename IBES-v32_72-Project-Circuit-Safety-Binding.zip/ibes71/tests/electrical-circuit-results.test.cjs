'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const Engine=require('../engineering/electrical-calculation-engine.cjs');
const Adapter=require('../engineering/project-engineering-adapter.cjs');
const html=fs.readFileSync(path.join(__dirname,'..','IBES.html'),'utf8');

test('page, unified engineering model and report use the shared circuit result function',()=>{
 assert.match(html,/function ibesCircuitEngineeringResult\(c\)/);
 assert.match(html,/const r=ibesCircuitEngineeringResult\(c\)/);
 assert.match(html,/const cr=\(P\.electricalCircuits\|\|\[\]\)\.map\(ibesCircuitEngineeringResult\)/);
 assert.match(html,/ELECTRICAL CIRCUITS \(shared calculation projection\)/);
});
test('missing required circuit fields remain NEEDS_DATA instead of displaying a calculated current',()=>{
 assert.match(html,/const missing=\['activePowerW','voltageV','powerFactor','phase'\]/);
 assert.match(html,/status:'NEEDS_DATA'/);
 const model=Adapter.buildProjectEngineeringModel({id:'p',electricalCircuits:[{id:'c',name:'Missing'}]});
 assert.equal(model.circuits[0].result.overallStatus,'NEEDS_DATA');
 assert.equal(model.circuits[0].result.designCurrentA,null);
});
test('complete sample circuit yields one reproducible preliminary current and remains uncertified',()=>{
 const c={id:'c-1',name:'Lighting',activePowerW:2300,voltageV:230,powerFactor:1,phase:'single'};
 const a=Engine.current(c), b=Engine.auditCircuit({...c,projectId:'p-1',circuitId:'c-1'});
 assert.equal(a.currentA,10);
 assert.equal(b.designCurrentA,a.currentA);
 assert.equal(b.normativeCompliance,'NOT_ASSESSED');
});
test('invalid circuit inputs are surfaced and not treated as a pass',()=>{
 const m=Adapter.buildProjectEngineeringModel({electricalCircuits:[{id:'bad',activePowerW:1000,voltageV:0,powerFactor:1,phase:'single'}]});
 assert.equal(m.circuits[0].result.overallStatus,'INVALID_INPUT');
 assert.notEqual(m.circuits[0].result.overallStatus,'PASS');
});
test('engineering UI explicitly reports no circuits rather than inferring from KNX inventory',()=>{
 assert.match(html,/No explicitly modelled electrical circuits\. KNX devices and group addresses are not converted into power circuits\./);
 assert.match(html,/P\.electricalCircuits\?\.length\|\|0/);
});
