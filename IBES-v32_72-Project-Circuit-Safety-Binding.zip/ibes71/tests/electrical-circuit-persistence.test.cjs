'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Model = require('../engineering/electrical-circuit-model.cjs');
const Adapter = require('../engineering/project-engineering-adapter.cjs');
const html = fs.readFileSync(path.join(__dirname, '..', 'IBES.html'), 'utf8');

const sampleCircuit = (patch = {}) => ({
  id: 'circuit-light-01', name: 'Lighting', activePowerW: 2300,
  voltageV: 230, powerFactor: 1, phase: 'single', ...patch
});

test('project save path stores the current project object and reports persistence mode', () => {
  assert.match(html, /const put=p=>new Promise/);
  assert.match(html, /window\.ibesNative\.saveProject\(p\)/);
  assert.match(html, /t\.objectStore\('p'\)\.put\(p\)/);
  assert.match(html, /fallbackWrite\(p\)/);
  assert.match(html, /async function save\(\)/);
  assert.match(html, /Saved in memory only — NOT persistent/);
});

test('legacy projects without circuits migrate additively without dropping unrelated fields', () => {
  const legacy = { id: 'legacy-01', schema: 4, name: 'Legacy', rooms: [{ id: 'r1' }], devices: [{ id: 'd1' }], custom: { preserved: true } };
  const migrated = Model.normalizeProject(JSON.parse(JSON.stringify(legacy)));
  assert.deepEqual(migrated.electricalCircuits, []);
  assert.deepEqual(migrated.rooms, legacy.rooms);
  assert.deepEqual(migrated.devices, legacy.devices);
  assert.deepEqual(migrated.custom, legacy.custom);
  assert.equal(migrated.electricalCircuitModelSchema, Model.MODEL_SCHEMA);
});

test('project JSON round-trip retains circuit identifiers, engineering inputs and optional fields', () => {
  let project = Model.addCircuit({ id: 'project-01', schema: 4, name: 'Office', rooms: [{ id: 'r1' }] }, sampleCircuit({ lengthM: 18, resistanceMilliOhmPerM: 12.1, reactanceMilliOhmPerM: 0.08, breakerRatingA: 16 }));
  project = Model.addCircuit(project, sampleCircuit({ id: 'circuit-socket-01', name: 'Sockets', activePowerW: 3450, powerFactor: 0.95 }));
  const reopened = Model.normalizeProject(JSON.parse(JSON.stringify(project)));
  assert.deepEqual(reopened.electricalCircuits, project.electricalCircuits);
  assert.deepEqual(reopened.rooms, project.rooms);
  assert.equal(reopened.electricalCircuits[0].id, 'circuit-light-01');
  assert.equal(reopened.electricalCircuits[0].resistanceMilliOhmPerM, 12.1);
  assert.equal(reopened.electricalCircuits[1].activePowerW, 3450);
});

test('invalid or duplicate circuit identities cannot enter through the model API', () => {
  const p = Model.addCircuit({ id: 'project-01' }, sampleCircuit());
  assert.throws(() => Model.addCircuit(p, sampleCircuit()), /Duplicate electrical circuit id/);
  assert.throws(() => Model.addCircuit(p, sampleCircuit({ id: '../unsafe' })), /Invalid electrical circuit/);
  assert.throws(() => Model.updateCircuit(p, 'circuit-light-01', { voltageV: 0 }), /Invalid electrical circuit/);
});

test('circuit page, single-line projection, tables and report share the exact result object', () => {
  const project = { id: 'project-01', schema: 4, name: 'Office', electricalCircuits: [sampleCircuit()] };
  const model = Adapter.buildProjectEngineeringModel(project);
  const canonical = model.resultsByCircuitId['circuit-light-01'];
  for (const view of ['circuitPage', 'singleLineDiagram', 'tables', 'report']) {
    assert.equal(model.views[view][0].circuitId, 'circuit-light-01');
    assert.equal(model.views[view][0].result, canonical, `${view} must reuse the canonical result object`);
  }
  assert.equal(canonical.normativeCompliance, 'NOT_ASSESSED');
});

test('HTML save, restore and report paths retain electricalCircuits and do not infer circuits from KNX', () => {
  assert.match(html, /if\(!Array\.isArray\(p\.electricalCircuits\)\)p\.electricalCircuits=\[\]/);
  assert.match(html, /function integrity\(p\)/);
  assert.match(html, /function rs\(txt\)/);
  assert.match(html, /ELECTRICAL CIRCUITS \(shared calculation projection\)/);
  assert.match(html, /No explicitly modelled electrical circuits\. KNX devices and group addresses are not converted into power circuits\./);
});

console.log('Electrical circuit persistence/integration regression tests completed.');
