/* IBES shared engineering + circuit-safety projection v1.0.0
 * Provides one immutable-by-convention result object per circuit to every engineering view.
 * Derived safety checks are read-time only and do not mutate project records.
 */
'use strict';
const Engineering = require('./project-engineering-adapter.cjs');
const Safety = require('./project-circuit-safety.cjs');
const VERSION = 'ibes-project-safety-view-model-1.0.0';
const VIEW_NAMES = Object.freeze(['circuitPage', 'singleLineDiagram', 'tables', 'report']);
function buildProjectSafetyViewModel(project, assessmentInputs = {}) {
  const engineering = Engineering.buildProjectEngineeringModel(project);
  const safety = Safety.assessProject(project, assessmentInputs);
  const safetyById = new Map(safety.circuits.map(item => [item.circuitId, item.result]));
  const circuits = engineering.circuits.map(item => {
    const safetyResult = safetyById.get(item.circuitId) || null;
    const combinedResult = Object.freeze({
      engineering: item.result,
      safety: safetyResult,
      status: item.result.overallStatus === 'INVALID_INPUT' ? 'INVALID_INPUT'
        : item.result.overallStatus === 'NEEDS_DATA' ? 'NEEDS_DATA'
        : safetyResult && safetyResult.status === 'ATTENTION_REQUIRED' ? 'ATTENTION_REQUIRED'
        : safetyResult && safetyResult.status === 'INCOMPLETE_NEEDS_DATA' ? 'INCOMPLETE_NEEDS_DATA'
        : 'ENGINEERING_RESULT_AVAILABLE',
      normativeCompliance: 'NOT_ASSESSED',
      disclaimer: 'A calculation result or basic safety check is not proof of NF C 15-100 conformity.'
    });
    return { circuitId: item.circuitId, name: item.name, sourceCircuit: item.sourceCircuit, result: combinedResult };
  });
  const byId = new Map(circuits.map(item => [item.circuitId, item.result]));
  const views = {};
  for (const viewName of VIEW_NAMES) {
    views[viewName] = engineering.views[viewName].map(item => ({ circuitId: item.circuitId, result: byId.get(item.circuitId) }));
  }
  const status = circuits.some(c => c.result.status === 'ATTENTION_REQUIRED') ? 'ATTENTION_REQUIRED'
    : circuits.some(c => ['NEEDS_DATA', 'INCOMPLETE_NEEDS_DATA', 'INVALID_INPUT'].includes(c.result.status)) ? 'INCOMPLETE_NEEDS_DATA'
    : 'BASIC_RESULTS_AVAILABLE';
  return {
    viewModelVersion: VERSION,
    projectId: engineering.projectId,
    status,
    normativeCompliance: 'NOT_ASSESSED',
    circuits,
    views,
    engineeringSummary: engineering.summary,
    safetySummary: safety.summary,
    limitations: [...new Set([...(safety.limitations || []), 'This is a source-level view model; the live application UI is not automatically wired by this module.', 'No engineering or safety result is stored in the source project records.'])]
  };
}
module.exports = { VERSION, VIEW_NAMES, buildProjectSafetyViewModel };
