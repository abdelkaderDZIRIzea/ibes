Plans of residential projects (PDF, PNG, SVG, DWG ...). Listed on the Files page under "Residential plans".
