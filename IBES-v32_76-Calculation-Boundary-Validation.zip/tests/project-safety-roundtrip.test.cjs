'use strict';
const assert = require('node:assert/strict');
const Model = require('../engineering/electrical-circuit-model.cjs');
const { buildProjectSafetyViewModel, VIEW_NAMES } = require('../engineering/project-safety-view-model.cjs');

const project0 = { id: 'roundtrip-project', name: 'Round-trip acceptance', schema: 1 };
const circuit = { id: 'circuit-a', name: 'Lighting', activePowerW: 2300, voltageV: 230, powerFactor: 1, phase: 'single' };
const project1 = Model.addCircuit(project0, circuit);
const project2 = Model.updateCircuit(project1, 'circuit-a', { activePowerW: 3450 });
const inputs = {};
function build(p, assessmentInputs = inputs) { return buildProjectSafetyViewModel(p, assessmentInputs); }
function ids(vm) { return vm.circuits.map(x => x.circuitId); }
function assertViewsShare(vm) {
  for (const name of VIEW_NAMES) {
    assert.deepEqual(vm.views[name].map(x => x.circuitId), ids(vm), `${name} circuit IDs must match project model`);
    for (const row of vm.views[name]) {
      const circuitRow = vm.circuits.find(x => x.circuitId === row.circuitId);
      assert.ok(circuitRow, `${name} references an existing circuit`);
      assert.strictEqual(row.result, circuitRow.result, `${name} shares the canonical result object`);
    }
  }
}

const beforeSave = build(project2);
assert.equal(beforeSave.circuits[0].result.engineering.designCurrentA, 15);
assertViewsShare(beforeSave);
console.log('PASS edited circuit recalculates from updated source inputs');

// Simulate a JSON persistence boundary: only project source data is serialized.
const persisted = JSON.parse(JSON.stringify(project2));
assert.equal(persisted.electricalCircuits[0].result, undefined);
assert.equal(persisted.electricalCircuits[0].safetyAssessment, undefined);
const afterReload = build(persisted);
assert.equal(afterReload.circuits[0].result.engineering.designCurrentA, 15);
assert.equal(afterReload.circuits[0].result.status, beforeSave.circuits[0].result.status);
assertViewsShare(afterReload);
console.log('PASS save/reload reconstruction preserves derived values and view consistency');

const removed = Model.removeCircuit(persisted, 'circuit-a');
const afterDelete = build(removed);
assert.equal(afterDelete.circuits.length, 0);
for (const name of VIEW_NAMES) assert.equal(afterDelete.views[name].length, 0);
console.log('PASS deleted circuits disappear from all projections after reload');

const withOrphan = build(persisted, { 'deleted-circuit': { cable: {}, shortCircuit: {} } });
assert.equal(withOrphan.status, 'INCOMPLETE_NEEDS_DATA');
assert.deepEqual(withOrphan.safetySummary.orphanAssessmentInputIds, ['deleted-circuit']);
console.log('PASS orphan assessment data cannot be silently treated as a complete project');

assert.throws(() => build(null), /project must be an object/);
console.log('PASS invalid project input fails explicitly');
console.log('\n5/5 project safety save/reload contract tests passed');
