@echo off
setlocal
cd /d "%~dp0desktop"
echo === IBES Portable Windows Build ===
where node >nul 2>nul || (echo Node.js LTS is required. & pause & exit /b 1)
where npm >nul 2>nul || (echo npm is required. & pause & exit /b 1)
echo Installing build dependencies...
call npm install || (echo Dependency installation failed. & pause & exit /b 1)
echo Building portable IBES executable...
call npm run dist:portable || (echo Build failed. Check the error above. & pause & exit /b 1)
echo.
echo Build completed. Open desktop
elease for the portable EXE.
pause
