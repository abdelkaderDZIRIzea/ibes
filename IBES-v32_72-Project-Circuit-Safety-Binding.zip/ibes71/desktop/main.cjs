const { app, BrowserWindow, ipcMain, shell } = require('electron');
const fs = require('node:fs/promises');
const path = require('node:path');
const { createLocalStore } = require('./local-store.cjs');

// Portable target sets PORTABLE_EXECUTABLE_DIR. In portable mode, keep all user data
// beside the executable so the whole folder can be backed up or moved together.
const portableDir = process.env.PORTABLE_EXECUTABLE_DIR;
if (portableDir) {
  try { app.setPath('userData', path.join(portableDir, 'IBES-Data')); } catch (e) { /* use Electron's default if the path cannot be changed */ }
} else {
  try { app.setPath('userData', path.join(app.getPath('userData'), 'IBES-Data')); } catch (e) { /* keep default */ }
}
const dataRoot = () => app.getPath('userData');
const backupsRoot = () => path.join(dataRoot(), 'backups');
const store = () => createLocalStore(dataRoot());
async function ensureStore() { await store().ensure(); }

ipcMain.handle('ibes:settings:get', async () => store().getSettings());
ipcMain.handle('ibes:settings:save', async (_e, value) => {
  const settings = await store().saveSettings(value);
  return { ok: true, settings };
});
ipcMain.handle('ibes:projects:list', async () => store().listProjects());
ipcMain.handle('ibes:projects:save', async (_e, project) => store().saveProject(project));
ipcMain.handle('ibes:projects:delete', async (_e, id) => store().deleteProject(id));
ipcMain.handle('ibes:storage:info', async () => ({ root: dataRoot(), portable: Boolean(process.env.PORTABLE_EXECUTABLE_DIR), settings: path.join(dataRoot(), 'settings.json'), projects: path.join(dataRoot(), 'projects'), backups: backupsRoot() }));

function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 940, minWidth: 980, minHeight: 650,
    title: 'IBES', backgroundColor: '#f2f2f0', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.cjs'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  const htmlPath = app.isPackaged ? path.join(process.resourcesPath, 'app', 'IBES.html') : path.join(__dirname, '..', 'IBES.html');
  win.loadFile(htmlPath);
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://') || url.startsWith('http://')) shell.openExternal(url);
    return { action: 'deny' };
  });
}
app.whenReady().then(async () => { await ensureStore(); createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
