/* IBES short-circuit protection assessment v1.0.0
 * Basic evidence-driven comparisons only; no standards compliance claim.
 * Requires manufacturer-provided let-through energy rather than guessing I²t.
 */
(function(root){'use strict';
 const VERSION='ibes-short-circuit-assessment-1.0.0';
 const required=['prospectiveFaultCurrentA','breakerBreakingCapacityA','breakerLetThroughEnergyA2s','conductorThermalCoefficientK','conductorSectionMm2','actualDisconnectionTimeS','maximumPermissibleDisconnectionTimeS','breakerReference','cableReference','dataSource'];
 function num(v,name){if(v===undefined||v===null||v===''||typeof v==='boolean'||!Number.isFinite(Number(v)))throw new TypeError(name+' must be an explicitly supplied finite number');const n=Number(v);if(n<=0)throw new RangeError(name+' must be > 0');return n;}
 function assess(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new TypeError('input must be an object');
  const missing=required.filter(k=>input[k]===undefined||input[k]===null||input[k]==='');
  if(missing.length)return {engineVersion:VERSION,status:'NEEDS_DATA',normativeCompliance:'NOT_ASSESSED',missingInputs:missing,message:'No short-circuit protection conclusion is produced until all required values and their traceable source are supplied.'};
  for(const k of ['breakerReference','cableReference','dataSource'])if(typeof input[k]!=='string'||!input[k].trim())throw new TypeError(k+' must be a non-empty traceable reference');
  const Ik=num(input.prospectiveFaultCurrentA,'prospectiveFaultCurrentA');
  const Icu=num(input.breakerBreakingCapacityA,'breakerBreakingCapacityA');
  const I2t=num(input.breakerLetThroughEnergyA2s,'breakerLetThroughEnergyA2s');
  const k=num(input.conductorThermalCoefficientK,'conductorThermalCoefficientK');
  const S=num(input.conductorSectionMm2,'conductorSectionMm2');
  const t=num(input.actualDisconnectionTimeS,'actualDisconnectionTimeS');
  const tmax=num(input.maximumPermissibleDisconnectionTimeS,'maximumPermissibleDisconnectionTimeS');
  const withstand=(k*S)**2;
  if(!Number.isFinite(withstand)||!Number.isFinite(I2t))throw new RangeError('numeric range exceeded');
  const checks=[
   {id:'fault_current_within_breaking_capacity',formula:'Ik ≤ Icu/Icn',actual:Ik,limit:Icu,unit:'A',passed:Ik<=Icu},
   {id:'cable_thermal_withstand',formula:'manufacturer I²t ≤ (k × S)²',actual:I2t,limit:withstand,unit:'A²s',passed:I2t<=withstand},
   {id:'disconnection_time',formula:'actual time ≤ supplied permissible time',actual:t,limit:tmax,unit:'s',passed:t<=tmax}
  ];
  return {engineVersion:VERSION,status:checks.every(c=>c.passed)?'PASS_BASIC_SHORT_CIRCUIT_CHECKS':'FAIL_BASIC_SHORT_CIRCUIT_CHECKS',normativeCompliance:'NOT_ASSESSED',inputs:{prospectiveFaultCurrentA:Ik,breakerBreakingCapacityA:Icu,breakerLetThroughEnergyA2s:I2t,conductorThermalCoefficientK:k,conductorSectionMm2:S,actualDisconnectionTimeS:t,maximumPermissibleDisconnectionTimeS:tmax,breakerReference:input.breakerReference.trim(),cableReference:input.cableReference.trim(),dataSource:input.dataSource.trim()},calculated:{conductorThermalWithstandA2s:withstand},checks,limitations:['Use manufacturer-verified breaker breaking capacity and let-through energy for the exact device and conditions.','The coefficient k and permissible disconnection time must be selected and justified for the actual conductor, insulation, circuit and applicable standard edition.','This basic assessment does not calculate prospective fault current or I²t, and does not establish NF C 15-100 conformity.','Verify protection settings, fault location, supply conditions, conductor starting temperature, device selectivity and all applicable requirements independently.']};
 }
 const api=Object.freeze({version:VERSION,assess});if(typeof module!=='undefined'&&module.exports)module.exports=api;if(root)root.IBESShortCircuitAssessment=api;
})(typeof window!=='undefined'?window:globalThis);
