'use strict';
const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');
const html=fs.readFileSync(require('node:path').join(__dirname,'..','IBES.html'),'utf8');
test('electrical circuits page is registered in navigation and renderer',()=>{assert.match(html,/ElectricalCircuits:\s*\(\)\s*=>\s*ibesElectricalCircuitsPage\(\)/);assert.match(html,/\['Architecture',\[[^\]]*'ElectricalCircuits'/);});
test('circuit UI has add, edit, delete and project save integration',()=>{for(const x of ['function ibesSaveCircuit()','function ibesEditCircuit(id)','function ibesDeleteCircuit(id)','save().then(()=>{tab=\'ElectricalCircuits\';render();})'])assert.ok(html.includes(x),`missing ${x}`);});
test('UI keeps electrical circuits separate and explicitly disclaims normative assessment',()=>{assert.match(html,/stored separately from KNX devices and group addresses/);assert.match(html,/NOT_ASSESSED/);});
test('UI validates required values and optional engineering inputs',()=>{assert.match(html,/circuit\.activePowerW<=0/);assert.match(html,/circuit\.powerFactor>1/);assert.match(html,/correctedCableCapacityA/);});

test('corruption recovery is clearly labelled and requires explicit user action',()=>{assert.match(html,/function restoreRecoveredProject\(\)/);assert.match(html,/P\._recoveredFromBackup/);assert.match(html,/Restore recovered project/);assert.match(html,/استعادة المشروع المسترجع/);assert.match(html,/_recoveredFromBackup\?' — '\+Z\('RECOVERED','مستعاد من نسخة احتياطية'\)/);});
