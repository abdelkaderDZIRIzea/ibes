'use strict';
/* Real-browser acceptance journey for IBES electrical circuits.
 * Requires `npm install` and `npx playwright install chromium`.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const root = path.resolve(__dirname, '..');
const htmlPath = path.join(root, 'IBES.html');
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };
const server = http.createServer((req, res) => {
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname); } catch { res.writeHead(400).end(); return; }
  const target = path.resolve(root, '.' + pathname);
  if (target !== root && !target.startsWith(root + path.sep)) { res.writeHead(403).end('Forbidden'); return; }
  const file = pathname === '/' ? htmlPath : target;
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404).end('Not found'); return; }
    res.writeHead(200, { 'content-type': mime[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' }); res.end(data);
  });
});

(async () => {
  let browser;
  const failures = [];
  let page;
  try {
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
    const address = server.address();
    browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu', '--allow-running-insecure-content', '--ignore-certificate-errors', '--disable-web-security'] });
    const context = await browser.newContext();
    page = await context.newPage();
    page.on('pageerror', e => failures.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error') failures.push('console: ' + m.text()); });
    await page.goto(`http://127.0.0.1:${address.port}/IBES.html`, { waitUntil: 'load', timeout: 60000 });
    // Normalize the UI language so accessible names remain deterministic even if the
    // browser profile previously stored Arabic. The journey still exercises the real login gate.
    const englishToggle = page.locator('[data-l="en"]');
    if (await englishToggle.count()) await englishToggle.click();
    await page.locator('#auth-form .auth-submit').click();
    await page.waitForFunction(() => !document.querySelector('#splash'), null, { timeout: 15000 });
    await page.waitForFunction(() => document.querySelector('#main') && document.querySelector('#main').innerText.length > 0, null, { timeout: 30000 });
    await page.waitForFunction(() => document.querySelector('#ps') || document.querySelector('#main'), null, { timeout: 30000 });

    // Create a uniquely named project through the actual application page and save flow.
    await page.evaluate(() => go('Project'));
    await page.locator('#p_name').fill('E2E Circuit Project');
    await page.locator('#p_desc').fill('Playwright save/restore acceptance');
    await page.locator('#p_id').fill('E2E-CIRCUIT');
    await page.getByRole('button', { name: /^Create$/ }).click();
    await page.waitForFunction(() => document.querySelector('#main')?.innerText.includes('E2E Circuit Project'));
    await page.waitForFunction(() => {
      const status = document.querySelector('#st')?.innerText || '';
      return /Saved|تم الحفظ/.test(status) && !/memory only|الذاكرة فقط/i.test(status);
    }, null, { timeout: 15000 });
    const projectId = await page.evaluate(() => P.id);

    // Add a circuit through the UI. Its preliminary current should be 10 A.
    await page.evaluate(() => go('ElectricalCircuits'));
    await page.locator('#c-name').fill('E2E Lighting');
    await page.locator('#activePowerW').fill('2300');
    await page.locator('#voltageV').fill('230');
    await page.locator('#powerFactor').fill('1');
    await page.locator('#c-phase').selectOption('single');
    await page.getByRole('button', { name: /Add circuit|إضافة الدائرة/ }).click();
    await page.waitForFunction(() => document.querySelector('#main')?.innerText.includes('E2E Lighting'));
    await page.waitForFunction(() => document.querySelector('#main')?.innerText.includes('10.000 A'));
    await page.waitForFunction(() => {
      const status = document.querySelector('#st')?.innerText || '';
      return /Saved|تم الحفظ/.test(status) && !/memory only|الذاكرة فقط/i.test(status);
    }, null, { timeout: 15000 });
    let circuitId = await page.evaluate(() => P.electricalCircuits.find(c => c.name === 'E2E Lighting')?.id);
    assert.ok(circuitId, 'circuit should be present in current project');

    // Edit through the actual editor and ensure the result recalculates from saved input.
    await page.locator('#main tr').filter({ hasText: 'E2E Lighting' }).getByRole('button', { name: /Edit|تعديل/ }).click();
    await page.locator('#activePowerW').fill('3450');
    await page.getByRole('button', { name: /Save changes|حفظ التعديلات/ }).click();
    await page.waitForFunction(() => document.querySelector('#main')?.innerText.includes('15.000 A'));
    await page.waitForFunction(() => {
      const status = document.querySelector('#st')?.innerText || '';
      return /Saved|تم الحفظ/.test(status) && !/memory only|الذاكرة فقط/i.test(status);
    }, null, { timeout: 15000 });

    // Reload the app, explicitly reopen the saved project, and verify persistence.
    await page.reload({ waitUntil: 'load', timeout: 60000 });
    await page.waitForFunction(() => document.querySelector('#ps')?.options.length > 0, null, { timeout: 30000 });
    await page.evaluate(id => sw(id), projectId);
    await page.evaluate(() => go('ElectricalCircuits'));
    await page.waitForFunction(() => document.querySelector('#main')?.innerText.includes('E2E Lighting'));
    await page.waitForFunction(() => document.querySelector('#main')?.innerText.includes('15.000 A'));
    const persisted = await page.evaluate(id => ({
      projectId: P.id,
      projectName: P.name,
      circuits: P.electricalCircuits.map(c => ({ id: c.id, name: c.name, activePowerW: c.activePowerW })),
      storageText: document.querySelector('#st')?.innerText || ''
    }), projectId);
    assert.equal(persisted.projectId, projectId);
    assert.equal(persisted.projectName, 'E2E Circuit Project');
    assert.ok(persisted.circuits.some(c => c.id === circuitId && c.activePowerW === 3450), 'edited circuit survives reload and reopen');

    // Delete the circuit, save, reload, and verify deletion is persistent too.
    page.once('dialog', dialog => dialog.accept());
    await page.locator('#main tr').filter({ hasText: 'E2E Lighting' }).getByRole('button', { name: /Delete|حذف/ }).click();
    await page.waitForFunction(id => !P.electricalCircuits.some(c => c.id === id), circuitId, { timeout: 10000 });
    await page.waitForFunction(() => {
      const status = document.querySelector('#st')?.innerText || '';
      return /Saved|تم الحفظ/.test(status) && !/memory only|الذاكرة فقط/i.test(status);
    }, null, { timeout: 15000 });
    await page.reload({ waitUntil: 'load', timeout: 60000 });
    await page.waitForFunction(() => document.querySelector('#ps')?.options.length > 0, null, { timeout: 30000 });
    await page.evaluate(id => sw(id), projectId);
    await page.evaluate(() => go('ElectricalCircuits'));
    const stillThere = await page.evaluate(id => P.electricalCircuits.some(c => c.id === id), circuitId);
    assert.equal(stillThere, false, 'deleted circuit remains deleted after reload');

    assert.deepEqual(failures, [], 'browser runtime should not emit JavaScript errors');
    console.log('PASS E2E: create project → add circuit → calculate → edit → save → reload/reopen → verify → delete → reload/reopen → verify deletion');
    console.log(JSON.stringify({ projectId, circuitId, finalCircuitCount: await page.evaluate(() => P.electricalCircuits.length), browserErrors: failures.length }, null, 2));
  } catch (e) {
    if (page) {
      const outDir = process.env.PLAYWRIGHT_ARTIFACTS || path.join(os.tmpdir(), 'ibes-playwright-artifacts');
      try { fs.mkdirSync(outDir, { recursive: true }); await page.screenshot({ path: path.join(outDir, 'ibes-e2e-failure.png'), fullPage: true }); } catch (shotError) { console.error('Could not capture failure screenshot:', shotError.message); }
      try { fs.writeFileSync(path.join(outDir, 'ibes-e2e-failure.txt'), String(e && e.stack || e) + '\n\nBrowser errors:\n' + failures.join('\n'), 'utf8'); } catch {}
      console.error('Failure artifacts directory:', outDir);
    }
    console.error('FAIL E2E:', e && e.stack || e);
    process.exitCode = 1;
  } finally {
    if (browser) await browser.close().catch(() => {});
    await new Promise(resolve => server.close(resolve));
  }
})();
