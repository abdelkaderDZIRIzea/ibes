const assert=require('node:assert/strict');
const S=require('../engineering/short-circuit-assessment.cjs');
let passed=0;function test(name,fn){try{fn();passed++;console.log('PASS',name)}catch(e){console.error('FAIL',name,e);process.exitCode=1}}
const base={prospectiveFaultCurrentA:4500,breakerBreakingCapacityA:6000,breakerLetThroughEnergyA2s:80000,conductorThermalCoefficientK:115,conductorSectionMm2:2.5,actualDisconnectionTimeS:0.1,maximumPermissibleDisconnectionTimeS:0.4,breakerReference:'manufacturer datasheet, exact model/revision',cableReference:'cable datasheet, exact product',dataSource:'verified project calculation records'};
test('missing inputs return NEEDS_DATA without a conclusion',()=>{const r=S.assess({prospectiveFaultCurrentA:5000});assert.equal(r.status,'NEEDS_DATA');assert.equal(r.checks,undefined);assert.ok(r.missingInputs.includes('breakerLetThroughEnergyA2s'));});
test('all three explicit comparisons pass',()=>{const r=S.assess(base);assert.equal(r.status,'PASS_BASIC_SHORT_CIRCUIT_CHECKS');assert.equal(r.normativeCompliance,'NOT_ASSESSED');assert.deepEqual(r.checks.map(x=>x.passed),[true,true,true]);assert.equal(r.calculated.conductorThermalWithstandA2s,82656.25);});
test('fails when prospective fault current exceeds breaker capacity',()=>{const r=S.assess({...base,prospectiveFaultCurrentA:7000});assert.equal(r.checks[0].passed,false);assert.equal(r.status,'FAIL_BASIC_SHORT_CIRCUIT_CHECKS');});
test('fails when manufacturer let-through energy exceeds cable withstand',()=>{const r=S.assess({...base,breakerLetThroughEnergyA2s:90000});assert.equal(r.checks[1].passed,false);});
test('fails when disconnection time exceeds explicitly supplied limit',()=>{const r=S.assess({...base,actualDisconnectionTimeS:0.5});assert.equal(r.checks[2].passed,false);});
test('rejects zero or negative engineering values',()=>assert.throws(()=>S.assess({...base,conductorSectionMm2:0}),/must be > 0/));
test('rejects nonnumeric supplied values',()=>assert.throws(()=>S.assess({...base,prospectiveFaultCurrentA:'unknown'}),/finite number/));
test('requires traceable source references',()=>assert.throws(()=>S.assess({...base,dataSource:' '}),/traceable reference/));
test('never claims normative compliance',()=>assert.equal(S.assess(base).normativeCompliance,'NOT_ASSESSED'));
console.log(`\n${passed}/9 short-circuit assessment tests passed`);
