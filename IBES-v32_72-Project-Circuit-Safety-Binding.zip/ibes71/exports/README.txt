Files exported by the app (CSV, JSON, SVG, PNG, HTML, XML). Listed on the Files page under "Exports". Files are only added, never overwritten.
