/* IBES Engineering Calculation Engine v1.0.0
 * Deterministic calculations only. Normative compliance requires validated, versioned rule data.
 */
(function(root){'use strict';
 const VERSION='ibes-electrical-engine-1.0.0';
 const finite=(v,n)=>{const x=Number(v);if(v===null||v===''||!Number.isFinite(x))throw new TypeError(n+' must be a finite number');return x};
 const positive=(v,n,allowZero=false)=>{const x=finite(v,n);if(allowZero?x<0:x<=0)throw new RangeError(n+(allowZero?' must be ≥ 0':' must be > 0'));return x};
 const finiteResult=(v,n)=>{if(!Number.isFinite(v))throw new RangeError(n+' result is outside the supported finite numeric range');return v};
 function current(input){
  const p=positive(input.activePowerW,'activePowerW'), u=positive(input.voltageV,'voltageV'), pf=positive(input.powerFactor,'powerFactor');
  if(pf>1)throw new RangeError('powerFactor must be ≤ 1');
  const phase=input.phase;
  if(phase!=='single'&&phase!=='three')throw new RangeError('phase must be explicitly set to single or three');
  const denominator=phase==='three'?Math.sqrt(3)*u*pf:u*pf;
  const ib=finiteResult(p/denominator,'current');
  return {engineVersion:VERSION,calculationId:'load-current',inputs:{activePowerW:p,voltageV:u,powerFactor:pf,phase},formula:phase==='three'?'Ib = P / (√3 × U × cosφ)':'Ib = P / (U × cosφ)',currentA:ib,unit:'A',status:'CALCULATED',normativeCompliance:'NOT_ASSESSED'};
 }
 function voltageDrop(input){
  const I=positive(input.currentA,'currentA'), L=positive(input.lengthM,'lengthM',true), R=positive(input.resistanceMilliOhmPerM,'resistanceMilliOhmPerM',true), X=positive(input.reactanceMilliOhmPerM??0,'reactanceMilliOhmPerM',true), U=positive(input.voltageV,'voltageV'), pf=positive(input.powerFactor,'powerFactor');
  if(pf>1)throw new RangeError('powerFactor must be ≤ 1');
  const phase=input.phase; if(phase!=='single'&&phase!=='three')throw new RangeError('phase must be explicitly set to single or three');
  const sin=Math.sqrt(Math.max(0,1-pf*pf)), factor=phase==='three'?Math.sqrt(3):2;
  const dropV=finiteResult(factor*L*I*(R*pf+X*sin)/1000,'voltage-drop'), percent=finiteResult(100*dropV/U,'voltage-drop percentage');
  let status='CALCULATED'; if(input.maxDropPercent!==undefined&&input.maxDropPercent!==null&&input.maxDropPercent!=='') status=percent<=positive(input.maxDropPercent,'maxDropPercent',true)?'WITHIN_USER_LIMIT':'EXCEEDS_USER_LIMIT';
  return {engineVersion:VERSION,calculationId:'voltage-drop',inputs:{currentA:I,lengthM:L,resistanceMilliOhmPerM:R,reactanceMilliOhmPerM:X,voltageV:U,powerFactor:pf,phase,maxDropPercent:input.maxDropPercent??null},formula:phase==='three'?'ΔU = √3 × L × I × (R cosφ + X sinφ) / 1000':'ΔU = 2 × L × I × (R cosφ + X sinφ) / 1000',dropV,dropPercent:percent,unit:'V and %',status,normativeCompliance:'NOT_ASSESSED',note:'R and X must be supplied in mΩ/m; maxDropPercent is a user-provided limit, not an embedded standard limit.'};
 }
 function protection(input){
  const Ib=positive(input.designCurrentA,'designCurrentA'), In=positive(input.breakerRatingA,'breakerRatingA'), Iz=positive(input.correctedCableCapacityA,'correctedCableCapacityA');
  const currentCoordination=In>=Ib&&In<=Iz;
  return {engineVersion:VERSION,calculationId:'overload-coordination',inputs:{designCurrentA:Ib,breakerRatingA:In,correctedCableCapacityA:Iz},checks:[{id:'Ib_le_In',formula:'Ib ≤ In',passed:Ib<=In,actual:Ib,limit:In},{id:'In_le_Iz',formula:'In ≤ Iz',passed:In<=Iz,actual:In,limit:Iz}],status:currentCoordination?'PASS_BASIC_CURRENT_COORDINATION':'FAIL_BASIC_CURRENT_COORDINATION',normativeCompliance:'NOT_ASSESSED',warning:'This basic current-coordination check does not verify trip curves, short-circuit breaking capacity, disconnection time, conductor adiabatic withstand, selectivity, or all applicable NF C 15-100 requirements.'};
 }
 function auditCircuit(input){
  const findings=[]; const calc=current({activePowerW:input.activePowerW,voltageV:input.voltageV,powerFactor:input.powerFactor,phase:input.phase});
  const Ib=calc.currentA;
  if(input.correctedCableCapacityA!==undefined&&input.correctedCableCapacityA!==null&&input.correctedCableCapacityA!==''){
   const Iz=positive(input.correctedCableCapacityA,'correctedCableCapacityA');
   findings.push({id:'cable-capacity',severity:Ib<=Iz?'info':'error',status:Ib<=Iz?'PASS':'FAIL',message:Ib<=Iz?'Calculated design current does not exceed the supplied corrected cable capacity.':'Calculated design current exceeds the supplied corrected cable capacity.',IbA:Ib,IzA:Iz});
  } else findings.push({id:'cable-capacity',severity:'warning',status:'NEEDS_DATA',message:'Provide a verified corrected cable current capacity based on installation method and correction factors.'});
  if(input.breakerRatingA!==undefined&&input.breakerRatingA!==null&&input.breakerRatingA!==''){
   if(input.correctedCableCapacityA!==undefined&&input.correctedCableCapacityA!==null&&input.correctedCableCapacityA!=='') findings.push({id:'basic-protection-coordination',severity:'info',...protection({designCurrentA:Ib,breakerRatingA:input.breakerRatingA,correctedCableCapacityA:input.correctedCableCapacityA})});
   else findings.push({id:'basic-protection-coordination',severity:'warning',status:'NEEDS_DATA',message:'Provide corrected cable capacity before basic current coordination can be checked.'});
  } else findings.push({id:'basic-protection-coordination',severity:'warning',status:'NEEDS_DATA',message:'Provide a breaker rating.'});
  if(input.lengthM!==undefined&&input.resistanceMilliOhmPerM!==undefined){
   const vd=voltageDrop({currentA:Ib,lengthM:input.lengthM,resistanceMilliOhmPerM:input.resistanceMilliOhmPerM,reactanceMilliOhmPerM:input.reactanceMilliOhmPerM??0,voltageV:input.voltageV,powerFactor:input.powerFactor,phase:input.phase,maxDropPercent:input.maxDropPercent});
   findings.push({id:'voltage-drop',severity:vd.status==='EXCEEDS_USER_LIMIT'?'warning':'info',...vd});
  } else findings.push({id:'voltage-drop',severity:'warning',status:'NEEDS_DATA',message:'Provide route length and verified cable R/X data to calculate voltage drop.'});
  return {engineVersion:VERSION,projectId:input.projectId??null,circuitId:input.circuitId??null,designCurrentA:Ib,findings,overallStatus:findings.some(x=>x.status==='FAIL'||x.status==='FAIL_BASIC_CURRENT_COORDINATION')?'FAIL':findings.some(x=>x.status==='NEEDS_DATA'||x.status==='EXCEEDS_USER_LIMIT')?'REVIEW':'CALCULATED_NOT_CERTIFIED',normativeCompliance:'NOT_ASSESSED',generatedAt:new Date().toISOString(),disclaimer:'Calculation output is not a declaration of conformity. Applicable standard edition, installation conditions, protection devices, and all required checks must be validated by a competent electrical designer.'};
 }
 const api=Object.freeze({version:VERSION,current,voltageDrop,protection,auditCircuit});
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
 if(root)root.IBESElectricalEngine=api;
})(typeof window!=='undefined'?window:globalThis);
