'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');

const DEFAULT_SETTINGS = Object.freeze({ language: 'ar', theme: 'light', autoSave: true, autoSaveMinutes: 2 });
function validId(value) {
  if (typeof value !== 'string' || value.length < 1 || value.length > 120) return null;
  return /^[a-zA-Z0-9_-]+$/.test(value) ? value : null;
}
function normalizeSettings(value) {
  const v = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  return {
    language: v.language === 'en' ? 'en' : 'ar',
    theme: v.theme === 'dark' ? 'dark' : 'light',
    autoSave: v.autoSave !== false,
    autoSaveMinutes: Math.min(10, Math.max(1, Number(v.autoSaveMinutes) || 2)),
    ...(typeof v.updatedAt === 'string' ? { updatedAt: v.updatedAt } : {})
  };
}
async function readJson(file, fallback) {
  try { return JSON.parse(await fs.readFile(file, 'utf8')); }
  catch (e) { if (e.code === 'ENOENT') return fallback; throw e; }
}
async function atomicJson(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp-${process.pid}-${crypto.randomBytes(6).toString('hex')}`;
  try {
    await fs.writeFile(tmp, JSON.stringify(value, null, 2), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
    await fs.rename(tmp, file);
  } catch (e) {
    await fs.rm(tmp, { force: true }).catch(() => {});
    throw e;
  }
}
function createLocalStore(rootDir) {
  if (typeof rootDir !== 'string' || !rootDir.trim()) throw new TypeError('A non-empty local storage root is required');
  const root = path.resolve(rootDir);
  const projectsDir = path.join(root, 'projects');
  const backupsDir = path.join(root, 'backups');
  const settingsFile = path.join(root, 'settings.json');
  const ensure = () => Promise.all([fs.mkdir(projectsDir, { recursive: true }), fs.mkdir(backupsDir, { recursive: true })]);
  const projectFile = id => {
    const clean = validId(id);
    if (!clean) throw new TypeError('Invalid project id: use 1–120 letters, digits, underscore or hyphen');
    return path.join(projectsDir, `${clean}.json`);
  };
  return Object.freeze({
    root, projectsDir, backupsDir, settingsFile, ensure,
    async getSettings() { return normalizeSettings(await readJson(settingsFile, DEFAULT_SETTINGS)); },
    async saveSettings(value) {
      const settings = { ...normalizeSettings(value), updatedAt: new Date().toISOString() };
      await atomicJson(settingsFile, settings); return settings;
    },
    async listProjects() {
      await ensure();
      const names = (await fs.readdir(projectsDir)).filter(n => n.endsWith('.json'));
      const rows = await Promise.all(names.map(async name => {
        const file = path.join(projectsDir, name);
        const id = name.slice(0, -5);
        try {
          const project = await readJson(file, null);
          if (project && typeof project === 'object' && !Array.isArray(project) && validId(project.id) && `${project.id}.json` === name) return project;
        } catch { /* try the last known-good snapshot below */ }
        // Recovery is explicit and non-destructive: surface a valid snapshot when the
        // primary file is corrupt, but never overwrite the primary automatically.
        if (!validId(id)) return null;
        try {
          const backup = await readJson(path.join(backupsDir, `${id}.json`), null);
          return backup && typeof backup === 'object' && !Array.isArray(backup) && backup.id === id ? { ...backup, _recoveredFromBackup: true } : null;
        } catch { return null; }
      }));
      return rows.filter(Boolean).sort((a, b) => String(b.upd || '').localeCompare(String(a.upd || '')));
    },
    async saveProject(project) {
      if (!project || typeof project !== 'object' || Array.isArray(project)) throw new TypeError('Invalid project payload');
      const file = projectFile(project.id);
      await ensure();
      // Keep one last-known-good project snapshot before replacing a valid primary.
      try {
        const current = await readJson(file, null);
        if (current && typeof current === 'object' && !Array.isArray(current) && current.id === project.id) {
          await atomicJson(path.join(backupsDir, `${project.id}.json`), current);
        }
      } catch { /* a corrupt primary is not promoted to a backup */ }
      await atomicJson(file, project);
      return { ok: true, id: project.id, savedAt: new Date().toISOString() };
    },
    async deleteProject(id) {
      const file = projectFile(id);
      try { await fs.unlink(file); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      try { await fs.unlink(path.join(backupsDir, `${id}.json`)); } catch (e) { if (e.code !== 'ENOENT') throw e; }
      return { ok: true };
    }
  });
}
module.exports = { createLocalStore, validId, normalizeSettings };
