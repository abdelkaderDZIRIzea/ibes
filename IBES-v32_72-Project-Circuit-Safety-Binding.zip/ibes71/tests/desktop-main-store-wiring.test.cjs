'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const main = fs.readFileSync(path.join(__dirname, '../desktop/main.cjs'), 'utf8');
const preload = fs.readFileSync(path.join(__dirname, '../desktop/preload.cjs'), 'utf8');
const store = fs.readFileSync(path.join(__dirname, '../desktop/local-store.cjs'), 'utf8');
for (const channel of ['ibes:settings:get','ibes:settings:save','ibes:projects:list','ibes:projects:save','ibes:projects:delete','ibes:storage:info']) {
  assert.ok(main.includes(`'${channel}'`), `main process must register ${channel}`);
  assert.ok(preload.includes(`'${channel}'`), `preload must expose ${channel}`);
}
assert.match(main, /require\('\.\/local-store\.cjs'\)/);
assert.match(main, /store\(\)\.saveProject\(project\)/);
assert.match(main, /store\(\)\.listProjects\(\)/);
assert.match(main, /store\(\)\.deleteProject\(id\)/);
assert.match(store, /fs\.rename\(tmp, file\)/);
assert.match(store, /validId\(project\.id\)/);
console.log('PASS all six Electron IPC channels are wired from preload to main and the tested local-store module');
console.log('1/1 desktop main/preload wiring test passed');
