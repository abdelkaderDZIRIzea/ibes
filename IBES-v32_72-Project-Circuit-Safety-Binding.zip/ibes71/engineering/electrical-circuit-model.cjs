/* IBES electrical circuit project model v1.0.0
 * Explicit, versioned project data contract. Does not infer circuits from KNX devices.
 */
'use strict';
const VERSION = 'ibes-electrical-circuit-model-1.0.0';
const MODEL_SCHEMA = 1;
const INPUT_FIELDS = Object.freeze({
  activePowerW: { unit: 'W', required: true, kind: 'positive-number' },
  voltageV: { unit: 'V', required: true, kind: 'positive-number' },
  powerFactor: { unit: '1', required: true, kind: 'number-0-exclusive-to-1-inclusive' },
  phase: { unit: 'enum', required: false, allowed: ['single', 'three'], default: 'single' },
  correctedCableCapacityA: { unit: 'A', required: false, kind: 'positive-number', sourceRequired: 'verified installation method and correction factors' },
  breakerRatingA: { unit: 'A', required: false, kind: 'positive-number' },
  lengthM: { unit: 'm', required: false, kind: 'non-negative-number' },
  resistanceMilliOhmPerM: { unit: 'mΩ/m', required: false, kind: 'non-negative-number' },
  reactanceMilliOhmPerM: { unit: 'mΩ/m', required: false, kind: 'non-negative-number', default: 0 },
  maxDropPercent: { unit: '%', required: false, kind: 'non-negative-number', sourceRequired: 'user-provided limit; not an embedded normative limit' }
});
function validId(id) { return typeof id === 'string' && /^[A-Za-z0-9_.-]{1,64}$/.test(id); }
function normalizeProject(project) {
  if (!project || typeof project !== 'object' || Array.isArray(project)) throw new TypeError('project must be an object');
  const out = { ...project };
  if (!Array.isArray(out.electricalCircuits)) out.electricalCircuits = [];
  out.electricalCircuitModelSchema = MODEL_SCHEMA;
  return out;
}
function validateCircuit(circuit) {
  const errors = [];
  if (!circuit || typeof circuit !== 'object' || Array.isArray(circuit)) return ['circuit must be an object'];
  if (!validId(circuit.id)) errors.push('id must be a unique safe string (1–64 characters)');
  if (typeof circuit.name !== 'string' || !circuit.name.trim()) errors.push('name is required');
  for (const k of ['activePowerW', 'voltageV']) {
    if (circuit[k] === undefined || circuit[k] === null || circuit[k] === '' || !Number.isFinite(Number(circuit[k])) || Number(circuit[k]) <= 0) errors.push(`${k} must be a finite number > 0`);
  }
  if (circuit.powerFactor === undefined || circuit.powerFactor === null || circuit.powerFactor === '' || !Number.isFinite(Number(circuit.powerFactor)) || Number(circuit.powerFactor) <= 0 || Number(circuit.powerFactor) > 1) errors.push('powerFactor must be > 0 and ≤ 1');
  if (circuit.phase !== undefined && !['single', 'three'].includes(circuit.phase)) errors.push('phase must be single or three');
  for (const k of ['correctedCableCapacityA', 'breakerRatingA']) if (circuit[k] !== undefined && circuit[k] !== null && circuit[k] !== '' && (!Number.isFinite(Number(circuit[k])) || Number(circuit[k]) <= 0)) errors.push(`${k} must be a finite number > 0 when supplied`);
  for (const k of ['lengthM', 'resistanceMilliOhmPerM', 'reactanceMilliOhmPerM', 'maxDropPercent']) if (circuit[k] !== undefined && circuit[k] !== null && circuit[k] !== '' && (!Number.isFinite(Number(circuit[k])) || Number(circuit[k]) < 0)) errors.push(`${k} must be a finite number ≥ 0 when supplied`);
  return errors;
}
function addCircuit(project, circuit) {
  const p = normalizeProject(project), errors = validateCircuit(circuit);
  if (errors.length) { const e = new TypeError('Invalid electrical circuit: ' + errors.join('; ')); e.validationErrors = errors; throw e; }
  if (p.electricalCircuits.some(c => c && c.id === circuit.id)) throw new Error(`Duplicate electrical circuit id: ${circuit.id}`);
  p.electricalCircuits = [...p.electricalCircuits, { ...circuit, phase: circuit.phase || 'single', modelSchema: MODEL_SCHEMA }];
  return p;
}
function updateCircuit(project, id, patch) {
  const p = normalizeProject(project), index = p.electricalCircuits.findIndex(c => c && c.id === id);
  if (index < 0) throw new Error(`Electrical circuit not found: ${id}`);
  const next = { ...p.electricalCircuits[index], ...patch, id, modelSchema: MODEL_SCHEMA };
  const errors = validateCircuit(next);
  if (errors.length) { const e = new TypeError('Invalid electrical circuit: ' + errors.join('; ')); e.validationErrors = errors; throw e; }
  p.electricalCircuits = p.electricalCircuits.map((c, i) => i === index ? next : c);
  return p;
}
function removeCircuit(project, id) {
  const p = normalizeProject(project);
  p.electricalCircuits = p.electricalCircuits.filter(c => !c || c.id !== id);
  return p;
}
module.exports = { VERSION, MODEL_SCHEMA, INPUT_FIELDS, normalizeProject, validateCircuit, addCircuit, updateCircuit, removeCircuit };
