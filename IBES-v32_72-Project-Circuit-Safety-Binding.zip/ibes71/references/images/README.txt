Images and reference drawings.
