'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const e2e = fs.readFileSync(path.join(__dirname, 'electrical-circuit-e2e.playwright.cjs'), 'utf8');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/engineering-e2e.yml'), 'utf8');

test('browser acceptance covers create, calculate, edit, reload/reopen and persistent delete', () => {
  for (const phrase of ["go('Project')", "go('ElectricalCircuits')", "#auth-form .auth-submit", "!document.querySelector('#splash')", "name: /^Create$/", "name: /Add circuit|إضافة الدائرة/", 'page.reload', 'sw(id)', "name: /Delete|حذف/", "'15.000 A'"]) assert.ok(e2e.includes(phrase), `E2E harness should cover ${phrase}`);
});
test('browser acceptance runs in CI with Chromium and does not masquerade as a source-only test', () => {
  assert.match(workflow, /browser-acceptance:/);
  assert.match(workflow, /playwright install --with-deps chromium/);
  assert.match(workflow, /node tests\/electrical-circuit-e2e\.playwright\.cjs/);
});
console.log('E2E acceptance harness contract tests completed.');
