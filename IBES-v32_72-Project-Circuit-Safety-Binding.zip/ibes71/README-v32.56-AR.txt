IBES v32.56 — Project Source Only

هذه حزمة مصدر المشروع. تحتوي على ملف IBES.html، ووحدات الهندسة، واختبارات المصدر، ومصدر Electron، وسير عمل GitHub Actions.
لا تحتوي على حزم HTML أو Desktop مستقلة جاهزة للتوزيع؛ التحزيم النهائي مؤجل حسب اتفاق العمل.

لتشغيل اختبارات المصدر:
  npm run test:engineering

لتشغيل اختبار Chromium الحقيقي في بيئة مجهزة:
  npm install
  npx playwright install --with-deps chromium
  npm run test:e2e

يجب التمييز بين اختبارات المصدر واختبارات المتصفح: اختبار عقد E2E لا يشغل Chromium. قبول المتصفح يتطلب نجاح browser-acceptance في GitHub Actions.

المطابقة مع NF C 15-100 غير مُقيّمة حتى الآن (NOT_ASSESSED).
راجع CHANGELOG-v32.56-AR.txt وREPORT-v32.56-AR.txt وNEXT-STAGE-v32.57-AR.txt.
