/* IBES project-to-safety adapter v1.0.0
 * Binds independently evidenced safety inputs to stable electrical-circuit IDs.
 * Does not infer engineering inputs, persist derived results, or claim conformity.
 */
'use strict';
const { normalizeProject, validateCircuit } = require('./electrical-circuit-model.cjs');
const { summarize } = require('./circuit-safety-summary.cjs');
const VERSION = 'ibes-project-circuit-safety-1.0.0';
function assessProject(project, assessmentInputs = {}) {
  if (!assessmentInputs || typeof assessmentInputs !== 'object' || Array.isArray(assessmentInputs)) {
    throw new TypeError('assessmentInputs must be an object keyed by circuit ID');
  }
  const normalized = normalizeProject(project);
  const seen = new Set();
  const circuits = normalized.electricalCircuits.map((circuit) => {
    const errors = validateCircuit(circuit);
    if (errors.length) throw new TypeError(`Invalid circuit ${circuit && circuit.id || '(unknown)'}: ${errors.join('; ')}`);
    if (seen.has(circuit.id)) throw new Error(`Duplicate electrical circuit id: ${circuit.id}`);
    seen.add(circuit.id);
    const inputs = Object.prototype.hasOwnProperty.call(assessmentInputs, circuit.id)
      ? assessmentInputs[circuit.id] : {};
    const result = summarize(inputs || {});
    return { circuitId: circuit.id, circuitName: circuit.name, result };
  });
  const orphanInputIds = Object.keys(assessmentInputs).filter(id => !seen.has(id));
  const failed = circuits.filter(x => x.result.status === 'ATTENTION_REQUIRED').map(x => x.circuitId);
  const incomplete = circuits.filter(x => x.result.status === 'INCOMPLETE_NEEDS_DATA').map(x => x.circuitId);
  const status = failed.length ? 'ATTENTION_REQUIRED'
    : incomplete.length ? 'INCOMPLETE_NEEDS_DATA'
    : 'BASIC_CHECKS_PASSED';
  return {
    engineVersion: VERSION,
    projectId: normalized.id ?? null,
    status,
    normativeCompliance: 'NOT_ASSESSED',
    circuitCount: circuits.length,
    circuits,
    summary: { failedCircuitIds: failed, incompleteCircuitIds: incomplete, orphanAssessmentInputIds: orphanInputIds },
    limitations: [
      'Results are derived at read time from explicitly supplied assessment inputs; they are not written into project circuit records.',
      'A basic pass is not proof of NF C 15-100 or other standards compliance.',
      'Orphan assessment inputs are reported and never silently attached to a different circuit.'
    ]
  };
}
module.exports = { VERSION, assessProject };
