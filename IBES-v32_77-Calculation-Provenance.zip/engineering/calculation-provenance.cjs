/* IBES calculation provenance envelope v1.0.0
 * Adds traceability without inventing a standards reference or altering engine output.
 */
'use strict';
const VERSION = 'ibes-calculation-provenance-1.0.0';
const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function buildProvenance(result, metadata = {}) {
  if (!isRecord(result)) throw new TypeError('result must be an object');
  if (!isRecord(metadata)) throw new TypeError('metadata must be an object');
  if (!isRecord(result.inputs)) throw new TypeError('result.inputs must be an object to create traceable provenance');
  const inputUnits = isRecord(metadata.inputUnits) ? { ...metadata.inputUnits } : {};
  const references = Array.isArray(metadata.references) ? metadata.references : [];
  const normalizedReferences = references.map((ref, index) => {
    if (!isRecord(ref) || typeof ref.title !== 'string' || !ref.title.trim()) {
      throw new TypeError(`references[${index}].title must be a non-empty string`);
    }
    return {
      title: ref.title.trim(),
      issuer: typeof ref.issuer === 'string' && ref.issuer.trim() ? ref.issuer.trim() : null,
      edition: typeof ref.edition === 'string' && ref.edition.trim() ? ref.edition.trim() : null,
      clause: typeof ref.clause === 'string' && ref.clause.trim() ? ref.clause.trim() : null,
      url: typeof ref.url === 'string' && /^https:\/\//i.test(ref.url) ? ref.url : null,
      verificationStatus: ref.verificationStatus === 'VERIFIED' ? 'VERIFIED' : 'UNVERIFIED'
    };
  });
  const copiedResult = structuredClone(result);
  return Object.freeze({
    provenanceVersion: VERSION,
    calculationId: typeof result.calculationId === 'string' ? result.calculationId : 'UNSPECIFIED',
    engineVersion: typeof result.engineVersion === 'string' ? result.engineVersion : null,
    inputs: structuredClone(result.inputs),
    inputUnits,
    formula: typeof result.formula === 'string' ? result.formula : null,
    outputs: Object.fromEntries(Object.entries(copiedResult).filter(([key]) => !['inputs', 'formula', 'engineVersion', 'calculationId'].includes(key))),
    references: normalizedReferences,
    referenceStatus: normalizedReferences.length === 0 ? 'NO_REFERENCE_SUPPLIED' : normalizedReferences.every(r => r.verificationStatus === 'VERIFIED') ? 'REFERENCES_VERIFIED_BY_CALLER' : 'REFERENCES_REQUIRE_VERIFICATION',
    normativeCompliance: 'NOT_ASSESSED',
    note: 'Provenance records the supplied inputs and references; it does not independently verify source accuracy or establish standards compliance.'
  });
}
module.exports = { VERSION, buildProvenance };
