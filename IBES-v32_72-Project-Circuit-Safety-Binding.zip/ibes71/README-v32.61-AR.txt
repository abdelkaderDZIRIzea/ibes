IBES v32.61 — حزمة المصدر

تتضمن هذه النسخة تحديثاً لاختبار قبول المتصفح: يبدأ الاختبار من شاشة الدخول ويكمل فقط بعد اختفائها، ثم يختبر إنشاء مشروع وإضافة دائرة وحسابها وتعديلها وإعادة تحميل المشروع وفتحه والتحقق من الحذف الدائم.

تشغيل اختبارات المصدر:
  npm run test:engineering

تشغيل رحلة المتصفح بعد تثبيت الاعتماديات:
  npm install
  npx playwright install chromium
  node tests/electrical-circuit-e2e.playwright.cjs

في CI تُثبت بيئة Chromium عبر .github/workflows/engineering-e2e.yml.

تنبيه: نجاح اختبارات المصدر لا يعني أن رحلة المتصفح أو اختبار Electron المرئي قد نجحا. حالة المطابقة NF C 15-100 هي NOT_ASSESSED إلى حين التحقق الفني الموثق.
