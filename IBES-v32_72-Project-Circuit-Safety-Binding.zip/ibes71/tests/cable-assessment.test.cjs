const assert=require('node:assert/strict');
const C=require('../engineering/cable-assessment.cjs');
let passed=0;
function test(name,fn){try{fn();passed++;console.log('PASS',name)}catch(e){console.error('FAIL',name,e);process.exitCode=1}}
const base={designCurrentA:16,breakerRatingA:20,referenceAmpacityA:30,referenceSource:'verified table: example edition/clause to be recorded',installationMethod:'B2',conductorMaterial:'copper',insulationType:'PVC',correctionFactors:[{id:'ambient',value:0.94},{id:'grouping',value:0.8}]};
test('missing cable evidence yields NEEDS_DATA and no guessed ampacity',()=>{const r=C.assess({designCurrentA:16});assert.equal(r.status,'NEEDS_DATA');assert.equal(r.correctedCableCapacityA,undefined);assert.ok(r.missingInputs.includes('referenceAmpacityA'));});
test('corrected ampacity multiplies explicitly supplied factors',()=>{const r=C.assess(base);assert.equal(r.status,'PASS_BASIC_CURRENT_COORDINATION');assert.ok(Math.abs(r.correctedCableCapacityA-22.56)<1e-12);assert.equal(r.normativeCompliance,'NOT_ASSESSED');});
test('fails coordination when breaker exceeds corrected capacity',()=>{const r=C.assess({...base,breakerRatingA:25});assert.equal(r.status,'FAIL_BASIC_CURRENT_COORDINATION');assert.equal(r.checks[1].passed,false);});
test('rejects correction factors above one rather than silently accepting them',()=>assert.throws(()=>C.assess({...base,correctionFactors:[{id:'ambient',value:1.1}]}),/must be ≤ 1/));
test('rejects duplicate correction factor IDs',()=>assert.throws(()=>C.assess({...base,correctionFactors:[{id:'ambient',value:.9},{id:'ambient',value:.8}]}),/duplicate correction factor/));
test('requires a traceable reference source',()=>assert.throws(()=>C.assess({...base,referenceSource:' '}),/referenceSource/));
test('rejects nonpositive design current',()=>assert.throws(()=>C.assess({...base,designCurrentA:0}),/must be > 0/));
test('does not claim normative conformity even when basic coordination passes',()=>assert.equal(C.assess(base).normativeCompliance,'NOT_ASSESSED'));
console.log(`\n${passed}/8 cable assessment tests passed`);
