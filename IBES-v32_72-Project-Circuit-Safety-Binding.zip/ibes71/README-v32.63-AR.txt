IBES v32.63 — حزمة المصدر

التحسين الرئيسي:
تم جعل GitHub Actions يستخدم أمر الاختبارات نفسه الموجود في package.json (npm run test:engineering)، حتى لا تتباعد قائمة الاختبارات المحلية وقائمة CI بمرور الوقت.

تشغيل اختبارات المصدر:
  npm run test:engineering

تشغيل اختبار المتصفح الحقيقي بعد تثبيت الاعتماديات:
  npm install
  npx playwright install chromium
  npm run test:e2e

تنبيه التحقق:
نجاح اختبارات المصدر لا يثبت نجاح رحلة المتصفح الفعلية ولا يغني عن اختبار واجهة Electron على Windows. معيار NF C 15-100 يبقى NOT_ASSESSED حتى مراجعة هندسية موثقة.
