IBES v32.50 — Project Source Only

هذه حزمة مصدر المشروع فقط. حزمة HTML المستقلة وحزمة Desktop المستقلة مؤجلتان إلى مرحلة التحزيم النهائي.

ابدأ بقراءة:
- REPORT-v32.50-AR.txt
- CHANGELOG-v32.50-AR.txt
- NEXT-STAGE-v32.51-AR.txt

الاختبارات:
  node tests/electrical-calculation-engine.test.cjs
  node tests/project-engineering-adapter.test.cjs
  node tests/rule-registry.test.cjs

مهم: هذه المرحلة تحسن عقد الربط واكتشاف شكل بيانات المشروع؛ لا تدعي أن الواجهات المرئية أو المخطط الأحادي أو التقارير أصبحت متصلة فعليًا بمحرك الحسابات.
