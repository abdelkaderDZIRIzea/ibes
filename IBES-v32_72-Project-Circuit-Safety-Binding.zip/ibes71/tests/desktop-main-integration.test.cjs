'use strict';
// Integration test for the actual main-process IPC handlers against a temporary filesystem.
// Electron's native window is intentionally not simulated as a real UI test.
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const Module = require('node:module');
(async () => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ibes-main-ipc-'));
  const handlers = new Map();
  const app = {
    setPath() {}, getPath() { return root; }, isPackaged: false,
    whenReady() { return Promise.resolve(); }, on() {}, quit() {}
  };
  class BrowserWindow { constructor() { this.webContents = { setWindowOpenHandler() {} }; } loadFile() {} static getAllWindows() { return [{}]; } }
  const electronMock = { app, BrowserWindow, ipcMain: { handle(name, fn) { handlers.set(name, fn); } }, shell: { openExternal() {} } };
  const originalLoad = Module._load;
  Module._load = function(request, parent, isMain) { if (request === 'electron') return electronMock; return originalLoad.call(this, request, parent, isMain); };
  try {
    require('../desktop/main.cjs');
    await new Promise(resolve => setImmediate(resolve));
    const invoke = (name, value) => { assert.ok(handlers.has(name), `missing IPC handler ${name}`); return handlers.get(name)({}, value); };
    const info = await invoke('ibes:storage:info');
    assert.equal(info.root, root);
    const project = { id: 'ipc-project', name: 'IPC Integration', upd: '2026-10-19T00:00:00.000Z', electricalCircuits: [{ id: 'c1', activePowerW: 2300, voltageV: 230, powerFactor: 1 }] };
    assert.equal((await invoke('ibes:projects:save', project)).ok, true);
    assert.deepEqual(await invoke('ibes:projects:list'), [project]);
    const updated = { ...project, upd: '2026-10-19T00:01:00.000Z', electricalCircuits: [{ ...project.electricalCircuits[0], activePowerW: 3450 }] };
    await invoke('ibes:projects:save', updated);
    const primary = path.join(root, 'projects', 'ipc-project.json');
    await fs.writeFile(primary, '{broken-primary', 'utf8');
    const recovered = await invoke('ibes:projects:list');
    assert.equal(recovered.length, 1);
    assert.equal(recovered[0]._recoveredFromBackup, true);
    assert.equal(recovered[0].electricalCircuits[0].activePowerW, 2300);
    assert.match(await fs.readFile(primary, 'utf8'), /^\{broken-primary/);
    await invoke('ibes:projects:save', recovered[0] && Object.fromEntries(Object.entries(recovered[0]).filter(([k]) => k !== '_recoveredFromBackup')));
    assert.deepEqual(await invoke('ibes:projects:list'), [project]);
    const settings = await invoke('ibes:settings:save', { language: 'ar', autoSaveMinutes: 4 });
    assert.equal(settings.settings.autoSaveMinutes, 4);
    assert.equal((await invoke('ibes:settings:get')).autoSaveMinutes, 4);
    await invoke('ibes:projects:delete', 'ipc-project');
    assert.deepEqual(await invoke('ibes:projects:list'), []);
    console.log('PASS main-process IPC integration: settings + project save/list + corruption recovery + explicit restore + delete');
  } finally {
    Module._load = originalLoad;
    await fs.rm(root, { recursive: true, force: true });
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
