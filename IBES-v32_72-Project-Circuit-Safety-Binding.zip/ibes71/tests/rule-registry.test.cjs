const assert = require('node:assert/strict');
const fs = require('node:fs'); const path = require('node:path');
const registry = JSON.parse(fs.readFileSync(path.join(__dirname,'../standards/rules-registry.v1.json'),'utf8'));
assert.equal(registry.defaultComplianceState,'NOT_ASSESSED');
assert.ok(Array.isArray(registry.rules) && registry.rules.length >= 4);
for (const rule of registry.rules) {
  assert.ok(rule.id && rule.standard && rule.topic);
  assert.equal(rule.enabled,false,`unverified rule must remain disabled: ${rule.id}`);
  assert.equal(rule.sourceVerified,false,`unverified source must not be marked verified: ${rule.id}`);
  assert.equal(rule.acceptanceLogic,null,`unverified acceptance logic must not be executable: ${rule.id}`);
  assert.ok(rule.edition === null && rule.clause === null,`unknown normative metadata must remain empty: ${rule.id}`);
}
console.log(`PASS ${registry.rules.length} unverified standard rules safely remain disabled; no conformity claims enabled.`);
