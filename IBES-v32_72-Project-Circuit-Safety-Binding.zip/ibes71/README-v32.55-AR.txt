IBES v32.55 — مصدر المشروع

هذه الحزمة تحتوي مصدر IBES واختبارات الحسابات ونموذج الدوائر ومحول سياق المشروع، بالإضافة إلى اختبار قبول Playwright وWorkflow لـ GitHub Actions.

تشغيل اختبارات المصدر:
  npm run test:engineering

تشغيل اختبار المتصفح بعد تثبيت Playwright وChromium:
  npm install
  npx playwright install chromium
  npm run test:e2e

اختبار المتصفح الجديد لم يُسجّل نجاحًا محليًا؛ البيئة الحالية حجبت localhost. شغّل GitHub Actions وراجع النتيجة الفعلية.

لا تُعد هذه النسخة حزمة HTML أو Desktop مستقلة. تم تأجيل الحزم المستقلة إلى التحزيم النهائي كما هو متفق عليه.
