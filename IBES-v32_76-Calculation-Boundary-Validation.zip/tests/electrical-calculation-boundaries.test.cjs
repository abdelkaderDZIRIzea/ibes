'use strict';
const assert = require('node:assert/strict');
const Engine = require('../engineering/electrical-calculation-engine.cjs');
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS', name); }
const valid = { activePowerW: 2300, voltageV: 230, powerFactor: 1, phase: 'single' };
test('rejects zero or negative active power', () => {
  for (const activePowerW of [0, -1]) assert.throws(() => Engine.current({ ...valid, activePowerW }), /activePowerW/);
});
test('rejects zero or negative voltage', () => {
  for (const voltageV of [0, -230]) assert.throws(() => Engine.current({ ...valid, voltageV }), /voltageV/);
});
test('rejects power factor outside (0, 1]', () => {
  for (const powerFactor of [0, -0.1, 1.01, 2]) assert.throws(() => Engine.current({ ...valid, powerFactor }), /powerFactor/);
});
test('rejects missing or unknown phase rather than guessing', () => {
  assert.throws(() => Engine.current({ ...valid, phase: undefined }), /phase/);
  assert.throws(() => Engine.current({ ...valid, phase: 'unknown' }), /phase/);
});
test('rejects non-finite values and numeric overflow', () => {
  for (const activePowerW of [NaN, Infinity, -Infinity, 'not-a-number']) assert.throws(() => Engine.current({ ...valid, activePowerW }));
  assert.throws(() => Engine.current({ ...valid, activePowerW: Number.MAX_VALUE, voltageV: Number.MIN_VALUE }), /finite numeric range/);
});
test('computes single-phase and three-phase current with explicit formulas', () => {
  assert.equal(Engine.current(valid).currentA, 10);
  assert.ok(Math.abs(Engine.current({ ...valid, phase: 'three' }).currentA - 2300 / (Math.sqrt(3) * 230)) < 1e-12);
});
test('returns calculated values without claiming normative compliance', () => {
  const result = Engine.current(valid);
  assert.equal(result.status, 'CALCULATED');
  assert.equal(result.normativeCompliance, 'NOT_ASSESSED');
});
console.log(`Electrical calculation boundary tests: ${passed}/7 passed`);
