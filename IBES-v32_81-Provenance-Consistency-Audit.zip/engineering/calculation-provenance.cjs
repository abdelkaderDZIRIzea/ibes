/* IBES calculation provenance envelope v1.1.0
 * Records traceability metadata without inventing standards references or altering engine output.
 */
'use strict';
const VERSION = 'ibes-calculation-provenance-1.1.0';
const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function deepFreeze(value, seen = new WeakSet()) {
  if (value === null || (typeof value !== 'object' && typeof value !== 'function') || seen.has(value)) return value;
  seen.add(value);
  for (const key of Reflect.ownKeys(value)) deepFreeze(value[key], seen);
  return Object.freeze(value);
}
function buildProvenance(result, metadata = {}) {
  if (!isRecord(result)) throw new TypeError('result must be an object');
  if (!isRecord(metadata)) throw new TypeError('metadata must be an object');
  if (!isRecord(result.inputs)) throw new TypeError('result.inputs must be an object to create traceable provenance');
  if (metadata.inputUnits !== undefined && !isRecord(metadata.inputUnits)) throw new TypeError('metadata.inputUnits must be an object');
  if (metadata.references !== undefined && !Array.isArray(metadata.references)) throw new TypeError('metadata.references must be an array');

  const inputUnits = metadata.inputUnits === undefined ? {} : structuredClone(metadata.inputUnits);
  for (const [key, unit] of Object.entries(inputUnits)) {
    if (!key.trim() || typeof unit !== 'string' || !unit.trim()) {
      throw new TypeError('inputUnits keys and unit labels must be non-empty strings');
    }
    inputUnits[key] = unit.trim();
  }
  const references = metadata.references === undefined ? [] : metadata.references;
  const normalizedReferences = references.map((ref, index) => {
    if (!isRecord(ref) || typeof ref.title !== 'string' || !ref.title.trim()) {
      throw new TypeError(`references[${index}].title must be a non-empty string`);
    }
    return {
      title: ref.title.trim(),
      issuer: typeof ref.issuer === 'string' && ref.issuer.trim() ? ref.issuer.trim() : null,
      edition: typeof ref.edition === 'string' && ref.edition.trim() ? ref.edition.trim() : null,
      clause: typeof ref.clause === 'string' && ref.clause.trim() ? ref.clause.trim() : null,
      url: typeof ref.url === 'string' && /^https:\/\//i.test(ref.url) ? ref.url : null,
      verificationStatus: ref.verificationStatus === 'VERIFIED' ? 'VERIFIED' : 'UNVERIFIED'
    };
  });
  const copiedResult = structuredClone(result);
  const envelope = {
    provenanceVersion: VERSION,
    calculationId: typeof result.calculationId === 'string' ? result.calculationId : 'UNSPECIFIED',
    engineVersion: typeof result.engineVersion === 'string' ? result.engineVersion : null,
    inputs: structuredClone(result.inputs),
    inputUnits,
    formula: typeof result.formula === 'string' ? result.formula : null,
    outputs: Object.fromEntries(Object.entries(copiedResult).filter(([key]) => !['inputs', 'formula', 'engineVersion', 'calculationId'].includes(key))),
    references: normalizedReferences,
    referenceStatus: normalizedReferences.length === 0 ? 'NO_REFERENCE_SUPPLIED' : normalizedReferences.every(r => r.verificationStatus === 'VERIFIED') ? 'REFERENCES_VERIFIED_BY_CALLER' : 'REFERENCES_REQUIRE_VERIFICATION',
    normativeCompliance: 'NOT_ASSESSED',
    note: 'Provenance records the supplied inputs and references; it does not independently verify source accuracy or establish standards compliance.'
  };
  return deepFreeze(envelope);
}
module.exports = { VERSION, buildProvenance };
