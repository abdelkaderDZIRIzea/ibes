const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('ibesNative', Object.freeze({
  getSettings: () => ipcRenderer.invoke('ibes:settings:get'),
  saveSettings: value => ipcRenderer.invoke('ibes:settings:save', value),
  getProjects: () => ipcRenderer.invoke('ibes:projects:list'),
  saveProject: project => ipcRenderer.invoke('ibes:projects:save', project),
  deleteProject: id => ipcRenderer.invoke('ibes:projects:delete', id),
  storageInfo: () => ipcRenderer.invoke('ibes:storage:info')
}));
