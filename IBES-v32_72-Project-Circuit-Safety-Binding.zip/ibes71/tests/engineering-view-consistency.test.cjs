'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const Adapter=require('../engineering/project-engineering-adapter.cjs');
const Engine=require('../engineering/electrical-calculation-engine.cjs');
const fs=require('node:fs'); const path=require('node:path');

test('circuit calculation, single-line diagram, tables and report share the exact same result object',()=>{
 const model=Adapter.buildProjectEngineeringModel({id:'consistency-project',electricalCircuits:[{id:'c-1',name:'Lighting',activePowerW:2300,voltageV:230,powerFactor:1,phase:'single'}]});
 const c=model.circuits[0];
 assert.equal(c.result.designCurrentA,10);
 for(const view of ['circuitPage','singleLineDiagram','tables','report']) {
   assert.equal(model.views[view].length,1);
   assert.equal(model.views[view][0].circuitId,c.circuitId);
   assert.strictEqual(model.views[view][0].result,c.result,`${view} must not recalculate a divergent result`);
 }
 assert.equal(model.summary.normativeCompliance,'NOT_ASSESSED');
 assert.equal(c.result.normativeCompliance,'NOT_ASSESSED');
});

test('changing an input rebuilds a consistent shared result across every projection',()=>{
 const make=power=>Adapter.buildProjectEngineeringModel({id:'p',electricalCircuits:[{id:'c',activePowerW:power,voltageV:230,powerFactor:1,phase:'single'}]});
 const before=make(2300), after=make(3450);
 assert.equal(before.circuits[0].result.designCurrentA,10);
 assert.equal(after.circuits[0].result.designCurrentA,15);
 for(const view of ['circuitPage','singleLineDiagram','tables','report']) assert.equal(after.views[view][0].result.designCurrentA,15);
 assert.equal(Engine.current({activePowerW:3450,voltageV:230,powerFactor:1,phase:'single'}).currentA,15);
});

test('normative matrix clearly records evidence gaps and official reference URLs',()=>{
 const doc=fs.readFileSync(path.join(__dirname,'../standards/NF-C-15-100-VERIFICATION-MATRIX-AR.md'),'utf8');
 assert.match(doc,/NOT_ASSESSED/);
 assert.match(doc,/afnor\.org/);
 assert.match(doc,/boutique\.afnor\.org/);
 assert.match(doc,/لا توجد شهادة مطابقة/);
});
console.log('PASS engineering view consistency and standards evidence tests');
