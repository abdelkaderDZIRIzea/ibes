IBES — الحزمة المحمولة v32.23

بناء نسخة Windows المحمولة:
1) ثبّت Node.js LTS على Windows.
2) افتح مجلد desktop في الطرفية.
3) نفّذ npm install
4) نفّذ npm run dist:portable
5) الناتج: desktop\release\IBES-Portable-32.23.0.exe

التخزين بجانب التطبيق:
عند تشغيل النسخة المحمولة من مجلد قابل للكتابة، ينشأ IBES-Data بجانب EXE، ويحتوي على settings.json وprojects وsession.json وbackups.
احتفظ بملف EXE ومجلد IBES-Data معاً عند النقل إلى جهاز آخر.

لا يتضمن هذا الأرشيف EXE جاهزاً؛ يجب بناء ملف Windows على جهاز Windows مع تنزيل اعتماديات Electron.

الإصدار 32.25: أيقونة إعدادات ثابتة فقط، وإصلاح فتح لوحة الإعدادات.
