'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { createLocalStore, validId, normalizeSettings } = require('../desktop/local-store.cjs');
(async () => {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'ibes-store-test-'));
  try {
    const store = createLocalStore(root);
    assert.deepEqual(await store.getSettings(), { language: 'ar', theme: 'light', autoSave: true, autoSaveMinutes: 2 });
    console.log('PASS local store supplies safe default settings when no file exists');

    const savedSettings = await store.saveSettings({ language: 'en', theme: 'dark', autoSave: false, autoSaveMinutes: 99, ignored: 'x' });
    assert.equal(savedSettings.language, 'en'); assert.equal(savedSettings.theme, 'dark');
    assert.equal(savedSettings.autoSave, false); assert.equal(savedSettings.autoSaveMinutes, 10);
    assert.deepEqual(await store.getSettings(), savedSettings);
    console.log('PASS settings are normalized and persist through a real filesystem round trip');

    const p = { id: 'project_01-ABC', name: 'Test project', upd: '2026-10-19T00:00:00.000Z', electricalCircuits: [{ id: 'c-1', name: 'Lighting', activePowerW: 2300, voltageV: 230, powerFactor: 1 }] };
    const result = await store.saveProject(p); assert.equal(result.ok, true);
    assert.deepEqual(await store.listProjects(), [p]);
    const updated = { ...p, upd: '2026-10-19T00:01:00.000Z', electricalCircuits: [{ ...p.electricalCircuits[0], activePowerW: 3450 }] };
    await store.saveProject(updated);
    assert.deepEqual(await store.listProjects(), [updated]);
    console.log('PASS project create/update persists circuit data and lists the latest saved version');

    const primary = path.join(store.projectsDir, `${p.id}.json`);
    await fs.writeFile(primary, '{broken-after-save', 'utf8');
    const recovered = await store.listProjects();
    assert.equal(recovered.length, 1);
    assert.equal(recovered[0].id, p.id);
    assert.equal(recovered[0]._recoveredFromBackup, true);
    assert.equal(recovered[0].electricalCircuits[0].activePowerW, 2300);
    assert.match(await fs.readFile(primary, 'utf8'), /^\{broken-after-save/); // recovery must not silently overwrite evidence
    console.log('PASS corrupted primary project exposes the last known-good backup without destructive auto-repair');
    await store.saveProject(updated); // explicitly restore by saving known-good data
    assert.deepEqual(await store.listProjects(), [updated]);
    console.log('PASS explicitly saving a known-good project restores the primary file');

    await assert.rejects(() => store.saveProject({ id: '../escape', name: 'bad' }), /Invalid project id/);
    await assert.rejects(() => store.saveProject({ id: 'two words', name: 'bad' }), /Invalid project id/);
    assert.equal(validId('../escape'), null); assert.equal(validId('project_01-ABC'), 'project_01-ABC');
    console.log('PASS invalid project IDs are rejected instead of silently normalized into colliding filenames');

    await fs.writeFile(path.join(store.projectsDir, 'corrupt.json'), '{broken', 'utf8');
    await fs.writeFile(path.join(store.projectsDir, 'mismatch.json'), JSON.stringify({ id: 'other-id', name: 'wrong filename' }), 'utf8');
    const listed = await store.listProjects(); assert.deepEqual(listed, [updated]);
    console.log('PASS corrupt JSON and filename/ID mismatches are ignored safely');

    assert.deepEqual(normalizeSettings({ language: 'fr', autoSaveMinutes: 0 }), { language: 'ar', theme: 'light', autoSave: true, autoSaveMinutes: 2 });
    // Project isolation: each project has an independent primary and backup snapshot.
    const p2 = { id: 'isolated-project-2', name: 'Independent project', upd: '2026-10-19T00:02:00.000Z', electricalCircuits: [{ id: 'c-2', activePowerW: 920 }] };
    await store.saveProject(p2);
    const p2Updated = { ...p2, upd: '2026-10-19T00:03:00.000Z', name: 'Independent project edited' };
    await store.saveProject(p2Updated);
    const p1Primary = path.join(store.projectsDir, `${p.id}.json`);
    await fs.writeFile(p1Primary, '{broken-project-one', 'utf8');
    const isolatedRows = await store.listProjects();
    assert.equal(isolatedRows.length, 2);
    const recoveredP1 = isolatedRows.find(x => x.id === p.id);
    const intactP2 = isolatedRows.find(x => x.id === p2.id);
    assert.equal(recoveredP1._recoveredFromBackup, true);
    assert.equal(intactP2.name, p2Updated.name);
    assert.equal(intactP2._recoveredFromBackup, undefined);
    console.log('PASS corruption recovery is isolated to one project and leaves other projects intact');

    // An invalid backup must never be surfaced as a recoverable project.
    await fs.writeFile(path.join(store.backupsDir, `${p.id}.json`), JSON.stringify({ id: 'different-id', name: 'wrong backup' }), 'utf8');
    const invalidBackupRows = await store.listProjects();
    assert.equal(invalidBackupRows.some(x => x.id === p.id), false);
    assert.equal(invalidBackupRows.some(x => x.id === p2.id), true);
    console.log('PASS mismatched backup identity is rejected rather than shown as recovered');

    await store.deleteProject(p.id);
    assert.equal(await fs.access(path.join(store.backupsDir, `${p.id}.json`)).then(() => true, () => false), false);
    assert.equal((await store.listProjects()).some(x => x.id === p.id), false);
    assert.deepEqual((await store.listProjects()).map(x => x.id), [p2.id]);
    await store.deleteProject(p.id); // idempotent delete
    await store.deleteProject(p2.id);
    assert.deepEqual(await store.listProjects(), []);
    console.log('PASS deletion removes primary and backup, is idempotent, and cannot resurrect deleted projects');
    console.log('11/11 desktop local-store integration tests passed');
  } finally { await fs.rm(root, { recursive: true, force: true }); }
})().catch(e => { console.error(e); process.exitCode = 1; });
