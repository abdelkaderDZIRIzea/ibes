/* IBES circuit safety summary v1.0.0
 * Aggregates separately evidenced cable and short-circuit assessments.
 * This is a summary layer, not a standards-compliance engine.
 */
(function(root){'use strict';
 const VERSION='ibes-circuit-safety-summary-1.0.0';
 const cableEngine=typeof require==='function'?require('./cable-assessment.cjs'):root.IBESCableAssessment;
 const shortEngine=typeof require==='function'?require('./short-circuit-assessment.cjs'):root.IBESShortCircuitAssessment;
 function summarize(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw new TypeError('input must be an object');
  const cable=input.cable?cableEngine.assess(input.cable):{status:'NEEDS_DATA',normativeCompliance:'NOT_ASSESSED',missingInputs:['cable assessment input']};
  const shortCircuit=input.shortCircuit?shortEngine.assess(input.shortCircuit):{status:'NEEDS_DATA',normativeCompliance:'NOT_ASSESSED',missingInputs:['short-circuit assessment input']};
  const items=[{id:'cable',result:cable},{id:'shortCircuit',result:shortCircuit}];
  const missing=items.flatMap(x=>(x.result.missingInputs||[]).map(field=>x.id+'.'+field));
  const failed=items.filter(x=>String(x.result.status||'').startsWith('FAIL')).map(x=>x.id);
  const pending=items.filter(x=>x.result.status==='NEEDS_DATA').map(x=>x.id);
  let status;
  if(failed.length)status='ATTENTION_REQUIRED';
  else if(pending.length)status='INCOMPLETE_NEEDS_DATA';
  else status='BASIC_CHECKS_PASSED';
  return {engineVersion:VERSION,status,normativeCompliance:'NOT_ASSESSED',assessments:{cable,shortCircuit},summary:{failedAssessments:failed,pendingAssessments:pending,missingInputs:missing},limitations:['The summary preserves each engine result and does not upgrade a basic check into standards compliance.','A passed summary means only that the supplied basic comparisons passed; engineering review and applicable-standard verification remain required.']};
 }
 const api=Object.freeze({version:VERSION,summarize});if(typeof module!=='undefined'&&module.exports)module.exports=api;if(root)root.IBESCircuitSafetySummary=api;
})(typeof window!=='undefined'?window:globalThis);
