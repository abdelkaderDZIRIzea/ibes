/* Project calculation provenance bridge v1.0.0
 * Adds a separate trace record for explicitly supplied electrical circuits.
 * It does not imply normative compliance or invent standard references.
 */
'use strict';
const Provenance = require('./calculation-provenance.cjs');
const VERSION = 'ibes-project-calculation-provenance-1.0.0';
const INPUT_KEYS = Object.freeze(['activePowerW','voltageV','powerFactor','phase','correctedCableCapacityA','breakerRatingA','lengthM','resistanceMilliOhmPerM','reactanceMilliOhmPerM','maxDropPercent']);
const UNITS = Object.freeze({activePowerW:'W',voltageV:'V',powerFactor:'1',phase:'enum',correctedCableCapacityA:'A',breakerRatingA:'A',lengthM:'m',resistanceMilliOhmPerM:'mΩ/m',reactanceMilliOhmPerM:'mΩ/m',maxDropPercent:'%'});
function buildCircuitProvenance(circuit, result) {
  if (!circuit || typeof circuit !== 'object' || Array.isArray(circuit)) throw new TypeError('circuit must be an object');
  if (!result || typeof result !== 'object' || Array.isArray(result)) throw new TypeError('result must be an object');
  const inputs = {};
  const units = {};
  for (const key of INPUT_KEYS) {
    if (circuit[key] !== undefined && circuit[key] !== null && circuit[key] !== '') {
      inputs[key] = circuit[key];
      units[key] = UNITS[key];
    }
  }
  if (!Object.keys(inputs).length) throw new TypeError('circuit has no explicit calculation inputs');
  const outputs = {
    designCurrentA: result.designCurrentA ?? null,
    overallStatus: result.overallStatus ?? 'UNKNOWN',
    normativeCompliance: 'NOT_ASSESSED',
    findings: Array.isArray(result.findings) ? result.findings : []
  };
  return Provenance.buildProvenance({
    calculationId: `project-circuit:${String(result.circuitId ?? circuit.id ?? circuit.circuitId ?? 'UNSPECIFIED')}`,
    engineVersion: result.engineVersion ?? null,
    inputs,
    formula: 'See calculation engine result; no independent formula is inferred by this bridge.',
    outputs
  }, { inputUnits: units, references: [] });
}
function buildProjectProvenance(viewModel) {
  if (!viewModel || typeof viewModel !== 'object' || !Array.isArray(viewModel.circuits)) throw new TypeError('viewModel.circuits must be an array');
  return Object.freeze({ version: VERSION, projectId: viewModel.projectId ?? null, normativeCompliance: 'NOT_ASSESSED', circuits: Object.freeze(viewModel.circuits.map(item => {
    const source = item.sourceCircuit;
    if (!source || !item.result || !item.result.engineVersion) return Object.freeze({ circuitId: item.circuitId, status: 'PROVENANCE_UNAVAILABLE', trace: null });
    try { return Object.freeze({ circuitId: item.circuitId, status: 'TRACE_AVAILABLE', trace: buildCircuitProvenance(source, item.result) }); }
    catch (error) { if (/no explicit calculation inputs/.test(String(error.message))) return Object.freeze({ circuitId: item.circuitId, status: 'PROVENANCE_UNAVAILABLE', trace: null }); throw error; }
  })) });
}
module.exports = { VERSION, INPUT_KEYS, UNITS, buildCircuitProvenance, buildProjectProvenance };
