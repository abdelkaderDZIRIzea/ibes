/* IBES project engineering adapter v1.1.0
 * Bridges the current IBES project schema to engineering traceability without
 * treating KNX group addresses/devices as electrical power circuits.
 * Electrical calculations are run only for explicitly supplied circuit records.
 */
'use strict';
const Engine = require('./electrical-calculation-engine.cjs');
const VERSION = 'ibes-project-engineering-adapter-1.1.0';
const REQUIRED = ['activePowerW','voltageV','powerFactor','phase'];
const ARRAY_FIELDS = ['buildings','floors','zones','rooms','devices','gas','links','rules','cabinets'];
function missing(v){ return v === undefined || v === null || v === ''; }
function idOf(project){ return project?.id ?? project?.projectId ?? null; }
function mapCircuit(project, circuit, index){
  const circuitId = circuit && (circuit.id ?? circuit.circuitId) != null ? String(circuit.id ?? circuit.circuitId) : `circuit-${index+1}`;
  const label = circuit && (circuit.name || circuit.label) ? String(circuit.name || circuit.label) : circuitId;
  const absent = REQUIRED.filter(k => !circuit || missing(circuit[k]));
  if(absent.length){
    return { circuitId, name:label, sourceCircuit:circuit || null,
      result:{ adapterVersion:VERSION, engineVersion:Engine.version, projectId:idOf(project), circuitId,
        overallStatus:'NEEDS_DATA', normativeCompliance:'NOT_ASSESSED', designCurrentA:null,
        findings:[{id:'required-inputs',severity:'warning',status:'NEEDS_DATA',missingInputs:absent,
          message:'Required circuit inputs are missing; no calculation or pass status was produced.'}],
        disclaimer:'No missing electrical input is inferred. This result is not a declaration of conformity.' } };
  }
  const input = { ...circuit, projectId:idOf(project), circuitId };
  let result;
  try { result = Engine.auditCircuit(input); }
  catch(error){
    result = {engineVersion:Engine.version, projectId:input.projectId, circuitId, overallStatus:'INVALID_INPUT',
      normativeCompliance:'NOT_ASSESSED', designCurrentA:null,
      findings:[{id:'input-validation',severity:'error',status:'INVALID_INPUT',message:String(error.message || error)}],
      disclaimer:'Input validation failed; no conformity conclusion is available.'};
  }
  return {circuitId,name:label,sourceCircuit:circuit,result};
}
function buildProjectEngineeringModel(project){
  if(!project || typeof project !== 'object' || Array.isArray(project)) throw new TypeError('project must be an object');
  // The live IBES project schema contains KNX/building entities, not a defined electrical-circuit collection.
  // Accept an explicitly named electricalCircuits collection; `circuits` is supported for adapter clients only.
  const circuitKey = Array.isArray(project.electricalCircuits) ? 'electricalCircuits' : Array.isArray(project.circuits) ? 'circuits' : null;
  const circuits = circuitKey ? project[circuitKey].map((c,i)=>mapCircuit(project,c,i)) : [];
  const resultsByCircuitId = Object.fromEntries(circuits.map(c=>[c.circuitId,c.result]));
  const counts = circuits.reduce((a,c)=>{a[c.result.overallStatus]=(a[c.result.overallStatus]||0)+1;return a;},{});
  const contextCounts = Object.fromEntries(ARRAY_FIELDS.map(k=>[k,Array.isArray(project[k])?project[k].length:0]));
  const missingCollections = ARRAY_FIELDS.filter(k=>!Array.isArray(project[k]));
  const hasCircuitCollection = circuitKey !== null;
  const integrationStatus = hasCircuitCollection ? 'CIRCUIT_COLLECTION_PRESENT' : 'CIRCUIT_COLLECTION_NOT_IN_PROJECT_SCHEMA';
  const context = Object.freeze({projectId:idOf(project),projectName:typeof project.name==='string'?project.name:null,
    schema:project.schema??null,counts:Object.freeze(contextCounts),missingCollections:Object.freeze(missingCollections),
    electricalCircuitCollection:circuitKey,integrationStatus,
    note:hasCircuitCollection ? 'Only explicitly supplied electrical circuit records are calculated; KNX devices and group addresses are inventory context, not assumed power circuits.' : 'The current project object has no explicit electricalCircuits/circuits collection. Electrical calculations are not inferred from KNX devices, rooms, or group addresses.'});
  const projectFindings = [];
  if(!hasCircuitCollection) projectFindings.push({id:'electrical-circuit-schema',severity:'warning',status:'NOT_INTEGRATED',message:'No explicit electrical circuit collection exists in the supplied project object; circuit calculations were not run.'});
  return Object.freeze({adapterVersion:VERSION,projectId:idOf(project),projectContext:context,
    circuits,resultsByCircuitId,summary:Object.freeze({circuitCount:circuits.length,counts:Object.freeze(counts),
      integrationStatus,normativeCompliance:'NOT_ASSESSED',projectFindings:Object.freeze(projectFindings)}),
    // These projections intentionally share each exact result object to prevent divergent recalculation.
    views:Object.freeze({circuitPage:circuits.map(c=>({circuitId:c.circuitId,result:c.result})),
      singleLineDiagram:circuits.map(c=>({circuitId:c.circuitId,result:c.result})),
      tables:circuits.map(c=>({circuitId:c.circuitId,result:c.result})),
      report:circuits.map(c=>({circuitId:c.circuitId,result:c.result}))})});
}
module.exports={VERSION,buildProjectEngineeringModel};
