IBES v32.59 — مصدر المشروع

- افتح مجلد desktop وثبّت تبعيات Electron حسب بيئة التطوير.
- اختبارات المصدر: من مجلد desktop نفّذ npm run test:engineering.
- اختبار المتصفح الحقيقي: ثبّت Playwright وChromium ثم نفّذ من جذر المشروع node tests/electrical-circuit-e2e.playwright.cjs.
- في GitHub Actions، عند فشل اختبار المتصفح تُرفع لقطة شاشة وسجل أخطاء كأثر باسم ibes-browser-acceptance-failure.
- هذه الحزمة مصدر المشروع فقط. لا توجد حزم HTML أو Desktop مستقلة في هذه المرحلة.
- المطابقة المعيارية NF C 15-100 لم تُقيّم بعد.
