IBES v32.53 — حزمة مصدر المشروع فقط

أبرز ما في هذه النسخة:
- نتائج حسابات الدوائر تأتي عبر دالة هندسية مشتركة بين صفحة الدوائر والنموذج الهندسي الموحد والتقرير.
- المدخلات الأساسية الناقصة تظهر NEEDS_DATA، والمدخلات غير الصالحة تظهر INVALID_INPUT.
- حالة المطابقة مع NF C 15-100 تبقى NOT_ASSESSED.

التحقق المحلي من المصدر (Node.js):
node --test tests/electrical-calculation-engine.test.cjs tests/electrical-circuit-model.test.cjs tests/project-engineering-adapter.test.cjs tests/electrical-circuit-ui-contract.test.cjs tests/electrical-circuit-results.test.cjs tests/rule-registry.test.cjs

مهم: هذه حزمة مصدر المشروع، وليست حزمة HTML مستقلة أو حزمة Desktop مبنية. لم يجرِ اختبار واجهة مرئي كامل في Electron أو متصفح حقيقي في هذه المرحلة.
