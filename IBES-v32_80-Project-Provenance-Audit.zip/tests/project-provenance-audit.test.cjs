'use strict';
const assert = require('node:assert/strict');
const Adapter = require('../engineering/project-engineering-adapter.cjs');
const Bridge = require('../engineering/project-calculation-provenance.cjs');
const Audit = require('../engineering/project-provenance-audit.cjs');
const project = { id: 'audit-project', electricalCircuits: [
  { id: 'lighting', activePowerW: 2300, voltageV: 230, powerFactor: 1, phase: 'single' },
  { id: 'incomplete' }
] };
const ledger = Bridge.buildProjectProvenance(Adapter.buildProjectEngineeringModel(project));
const report = Audit.auditProjectProvenance(ledger);
assert.equal(report.status, 'NEEDS_REVIEW');
assert.equal(report.circuitCount, 2);
assert.equal(report.errorCount, 0);
assert.equal(report.warningCount, 1);
assert.equal(report.normativeCompliance, 'NOT_ASSESSED');
const goodOnly = { projectId: 'p', circuits: [ledger.circuits[0]] };
assert.equal(Audit.auditProjectProvenance(goodOnly).status, 'STRUCTURALLY_VALID');
const duplicate = { projectId: 'p', circuits: [ledger.circuits[0], ledger.circuits[0]] };
assert.ok(Audit.auditProjectProvenance(duplicate).findings.some(x => x.code === 'DUPLICATE_CIRCUIT_ID'));
const badUnit = structuredClone(goodOnly);
badUnit.circuits[0].trace.inputUnits.activePowerW = '';
assert.ok(Audit.auditProjectProvenance(badUnit).findings.some(x => x.code === 'MISSING_INPUT_UNIT'));
const falseCompliance = structuredClone(goodOnly);
falseCompliance.circuits[0].trace.normativeCompliance = 'COMPLIANT';
assert.equal(Audit.auditProjectProvenance(falseCompliance).status, 'INVALID');
assert.ok(Audit.auditProjectProvenance(falseCompliance).findings.some(x => x.code === 'UNSUPPORTED_COMPLIANCE_CLAIM'));
const noTrace = { circuits: [{ circuitId: 'x', status: 'TRACE_AVAILABLE', trace: null }] };
assert.equal(Audit.auditProjectProvenance(noTrace).status, 'INVALID');
assert.throws(() => Audit.auditProjectProvenance(null), /ledger must be an object/);
assert.throws(() => Audit.auditProjectProvenance({ circuits: null }), /ledger.circuits must be an array/);
console.log('PASS project provenance audit: 12 assertions');
