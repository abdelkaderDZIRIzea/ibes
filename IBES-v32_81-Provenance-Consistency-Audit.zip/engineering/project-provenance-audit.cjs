/* IBES project provenance audit v1.0.0
 * Read-only structural audit of the project calculation provenance ledger.
 * It checks trace integrity, not electrical correctness or standards compliance.
 */
'use strict';
const VERSION = 'ibes-project-provenance-audit-1.0.0';
const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function auditProjectProvenance(ledger) {
  const findings = [];
  if (!isRecord(ledger)) throw new TypeError('ledger must be an object');
  if (!Array.isArray(ledger.circuits)) throw new TypeError('ledger.circuits must be an array');
  const seen = new Set();
  const seenCalculations = new Set();
  for (let index = 0; index < ledger.circuits.length; index++) {
    const entry = ledger.circuits[index];
    const path = `circuits[${index}]`;
    if (!isRecord(entry)) {
      findings.push({ code: 'INVALID_ENTRY', path, severity: 'error' });
      continue;
    }
    if (entry.circuitId === undefined || entry.circuitId === null || String(entry.circuitId).trim() === '') {
      findings.push({ code: 'MISSING_CIRCUIT_ID', path, severity: 'error' });
    } else {
      const id = String(entry.circuitId);
      if (seen.has(id)) findings.push({ code: 'DUPLICATE_CIRCUIT_ID', path, circuitId: id, severity: 'error' });
      seen.add(id);
    }
    if (entry.status === 'PROVENANCE_UNAVAILABLE') {
      if (entry.trace !== null) findings.push({ code: 'UNAVAILABLE_TRACE_MUST_BE_NULL', path, severity: 'error' });
      findings.push({ code: 'PROVENANCE_UNAVAILABLE', path, circuitId: entry.circuitId ?? null, severity: 'warning' });
      continue;
    }
    if (entry.status !== 'TRACE_AVAILABLE') {
      findings.push({ code: 'UNKNOWN_ENTRY_STATUS', path, severity: 'error' });
      continue;
    }
    const trace = entry.trace;
    if (!isRecord(trace)) {
      findings.push({ code: 'MISSING_TRACE', path, severity: 'error' });
      continue;
    }
    if (!isRecord(trace.inputs) || Object.keys(trace.inputs).length === 0) findings.push({ code: 'MISSING_TRACE_INPUTS', path, severity: 'error' });
    if (!isRecord(trace.inputUnits)) findings.push({ code: 'INVALID_INPUT_UNITS', path, severity: 'error' });
    else if (isRecord(trace.inputs)) {
      for (const key of Object.keys(trace.inputs)) {
        if (typeof trace.inputUnits[key] !== 'string' || !trace.inputUnits[key].trim()) {
          findings.push({ code: 'MISSING_INPUT_UNIT', path, input: key, severity: 'error' });
        }
      }
    }
    if (!isRecord(trace.outputs)) findings.push({ code: 'MISSING_TRACE_OUTPUTS', path, severity: 'error' });
    if (trace.normativeCompliance !== 'NOT_ASSESSED') findings.push({ code: 'UNSUPPORTED_COMPLIANCE_CLAIM', path, severity: 'error' });
    if (typeof trace.calculationId !== 'string' || !trace.calculationId.trim()) {
      findings.push({ code: 'MISSING_CALCULATION_ID', path, severity: 'error' });
    } else {
      if (seenCalculations.has(trace.calculationId)) findings.push({ code: 'DUPLICATE_CALCULATION_ID', path, calculationId: trace.calculationId, severity: 'error' });
      seenCalculations.add(trace.calculationId);
    }
    if (Array.isArray(trace.references)) {
      for (let r = 0; r < trace.references.length; r++) {
        const ref = trace.references[r];
        if (!isRecord(ref)) {
          findings.push({ code: 'INVALID_REFERENCE', path, referenceIndex: r, severity: 'error' });
          continue;
        }
        if (typeof ref.title !== 'string' || !ref.title.trim()) findings.push({ code: 'MISSING_REFERENCE_TITLE', path, referenceIndex: r, severity: 'error' });
        if (ref.url !== null && ref.url !== undefined && (typeof ref.url !== 'string' || !/^https:\/\//i.test(ref.url))) {
          findings.push({ code: 'INVALID_REFERENCE_URL', path, referenceIndex: r, severity: 'error' });
        }
      }
    } else findings.push({ code: 'INVALID_REFERENCES', path, severity: 'error' });
  }
  const errors = findings.filter(item => item.severity === 'error').length;
  const warnings = findings.filter(item => item.severity === 'warning').length;
  return Object.freeze({ version: VERSION, projectId: ledger.projectId ?? null, circuitCount: ledger.circuits.length,
    status: errors ? 'INVALID' : warnings ? 'NEEDS_REVIEW' : 'STRUCTURALLY_VALID', errorCount: errors,
    warningCount: warnings, normativeCompliance: 'NOT_ASSESSED', findings: Object.freeze(findings.map(item => Object.freeze(item))),
    note: 'This audit checks provenance structure only; it does not verify calculations, reference contents, or NF C 15-100 compliance.' });
}
module.exports = { VERSION, auditProjectProvenance };
