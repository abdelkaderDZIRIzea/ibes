'use strict';
const assert = require('node:assert/strict');
const Adapter = require('../engineering/project-engineering-adapter.cjs');
const Bridge = require('../engineering/project-calculation-provenance.cjs');
const project = { id:'p-provenance', electricalCircuits:[
 { id:'c1', name:'Lighting', activePowerW:2300, voltageV:230, powerFactor:1, phase:'single' },
 { id:'c2', name:'Missing inputs' }
]};
const model = Adapter.buildProjectEngineeringModel(project);
const ledger = Bridge.buildProjectProvenance(model);
assert.equal(ledger.version, 'ibes-project-calculation-provenance-1.0.0');
assert.equal(ledger.projectId, 'p-provenance');
assert.equal(ledger.circuits.length, 2);
assert.equal(ledger.circuits[0].status, 'TRACE_AVAILABLE');
assert.equal(ledger.circuits[0].trace.inputs.activePowerW, 2300);
assert.equal(ledger.circuits[0].trace.inputUnits.voltageV, 'V');
assert.equal(ledger.circuits[0].trace.outputs.outputs.designCurrentA, 10);
assert.equal(ledger.circuits[0].trace.normativeCompliance, 'NOT_ASSESSED');
assert.equal(ledger.circuits[0].trace.referenceStatus, 'NO_REFERENCE_SUPPLIED');
assert.equal(ledger.circuits[1].status, 'PROVENANCE_UNAVAILABLE');
project.electricalCircuits[0].activePowerW = 9999;
assert.equal(ledger.circuits[0].trace.inputs.activePowerW, 2300, 'ledger snapshots inputs defensively');
assert.ok(Object.isFrozen(ledger) && Object.isFrozen(ledger.circuits) && Object.isFrozen(ledger.circuits[0].trace));
assert.throws(() => Bridge.buildProjectProvenance({ circuits: null }), /circuits must be an array/);
console.log('PASS project calculation provenance bridge: 12 assertions');
